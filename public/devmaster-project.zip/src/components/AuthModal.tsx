import React, { useState } from 'react';
import {
  LogIn,
  UserPlus,
  KeyRound,
  ShieldAlert,
  Users,
  GraduationCap,
  Sparkles,
  AlertCircle,
  Eye,
  EyeOff,
  Lock,
  CheckCircle2,
  Calendar,
  ShieldCheck,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { loginUser, registerStudent } from '../services/storage';
import { AuthUser, Student, Teacher } from '../types';
import { OWNER_CREDENTIALS } from '../data/mockData';
import { GoogleAuthDialog } from './GoogleAuthDialog';

interface AuthModalProps {
  initialTab?: 'login' | 'register';
  onClose: () => void;
  onAuthSuccess: (user: AuthUser) => void;
  onStudentRegistered: (student: Student, teacher: Teacher | null) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  initialTab = 'login',
  onClose,
  onAuthSuccess,
  onStudentRegistered,
}) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>(initialTab);

  // Login form state
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showGoogleModal, setShowGoogleModal] = useState(false);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regSurname, setRegSurname] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [regPhone, setRegPhone] = useState('+998 ');
  const [regEmail, setRegEmail] = useState('');
  const [regAge, setRegAge] = useState(16);

  // Odamlikni tasdiqlash
  const [captchaNum1] = useState(Math.floor(Math.random() * 8) + 2);
  const [captchaNum2] = useState(Math.floor(Math.random() * 8) + 1);
  const [captchaAnswer, setCaptchaAnswer] = useState('');
  const [isHumanConfirmed, setIsHumanConfirmed] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const res = loginUser(loginUsername, loginPassword);
    if (res.success && res.user) {
      onAuthSuccess(res.user);
      onClose();
    } else {
      setErrorMessage(res.message);
    }
  };

  const handleQuickLogin = (user: string, pass: string) => {
    setLoginUsername(user);
    setLoginPassword(pass);
    const res = loginUser(user, pass);
    if (res.success && res.user) {
      onAuthSuccess(res.user);
      onClose();
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (regAge < 13) {
      setErrorMessage("⚠️ Xavfsizlik qoidalariga ko'ra (COPPA), platformadan faqat 13 yosh va undan kattalar ro'yxatdan o'tishi mumkin!");
      return;
    }

    const expected = captchaNum1 + captchaNum2;
    if (parseInt(captchaAnswer) !== expected || !isHumanConfirmed) {
      setErrorMessage(`⚠️ Odamlikni tasdiqlash: Iltimos, "${captchaNum1} + ${captchaNum2} = ?" hisobini to'g'ri yozing va katakchani belgilang!`);
      return;
    }

    if (!regName.trim() || !regSurname.trim()) {
      setErrorMessage("Iltimos, ism va familiyangizni kiriting!");
      return;
    }

    if (!regUsername.trim()) {
      setErrorMessage("Iltimos, login (username) tanlang!");
      return;
    }

    if (!regPassword || regPassword.length < 4) {
      setErrorMessage("Parol kamida 4 ta belgidan iborat bo'lishi kerak!");
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMessage("Parollar bir-biriga mos kelmadi!");
      return;
    }

    try {
      const res = registerStudent({
        name: regName.trim(),
        surname: regSurname.trim(),
        username: regUsername.trim().toLowerCase(),
        password: regPassword,
        phone: regPhone.trim(),
        email: regEmail.trim(),
        age: Number(regAge),
      });

      onStudentRegistered(res.student, res.teacher);

      const authStudent: AuthUser = {
        id: res.student.id,
        name: `${res.student.name} ${res.student.surname}`,
        username: res.student.username,
        role: 'student',
        avatar: res.student.avatar,
      };

      onAuthSuccess(authStudent);
      onClose();

      try {
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
      } catch (err) {
        console.log(err);
      }
    } catch (err: any) {
      setErrorMessage(err.message || "Xatolik yuz berdi");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Tab Switcher */}
        <div className="flex bg-slate-950 p-1 rounded-2xl border border-slate-800 mb-5">
          <button
            type="button"
            onClick={() => {
              setActiveTab('login');
              setErrorMessage('');
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'login'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            Kirish (Login)
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('register');
              setErrorMessage('');
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'register'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            Ro'yxatdan O'tish
          </button>
        </div>

        {/* Google Sign-in Button */}
        <div className="mb-4">
          <button
            type="button"
            onClick={() => setShowGoogleModal(true)}
            className="w-full py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-800 rounded-xl font-semibold text-xs flex items-center justify-center gap-2.5 shadow-md transition-colors border border-slate-200"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            Google orqali kirish / ro'yxatdan o'tish
          </button>

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-800" />
            </div>
            <div className="relative flex justify-center text-[11px]">
              <span className="bg-slate-900 px-3 text-slate-500 font-medium">yoki parolingiz bilan</span>
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* TAB 1: LOGIN */}
        {activeTab === 'login' ? (
          <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Login yoki Email (Admin: olimjonalimjonov12@gmail.com)
              </label>
              <input
                type="text"
                required
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                placeholder="lord_o1 yoki talaba login"
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Parol</label>
              <div className="relative">
                <input
                  type={showLoginPassword ? 'text' : 'password'}
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••"
                  className="w-full px-3.5 py-2.5 pr-9 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPassword(!showLoginPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-white"
                >
                  {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 mt-4"
            >
              <LogIn className="w-4 h-4" />
              Tizimga Kirish
            </button>

            {/* Quick Owner Shortcut */}
            <div className="pt-3 border-t border-slate-800 text-center">
              <button
                type="button"
                onClick={() => handleQuickLogin(OWNER_CREDENTIALS.email, OWNER_CREDENTIALS.password)}
                className="text-[11px] text-amber-400 hover:text-amber-300 hover:underline inline-flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3" />
                Bosh Admin (Owner) tezkor kirish: olimjonalimjonov12@gmail.com
              </button>
            </div>
          </form>
        ) : (
          /* TAB 2: REGISTER */
          <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Ism *</label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="Sardor"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-medium mb-1">Familiya *</label>
                <input
                  type="text"
                  required
                  value={regSurname}
                  onChange={(e) => setRegSurname(e.target.value)}
                  placeholder="Komilov"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-slate-300 font-medium mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                  Yoshingiz * (13+)
                </label>
                <input
                  type="number"
                  required
                  min={13}
                  value={regAge}
                  onChange={(e) => setRegAge(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-medium mb-1">Login (Username) *</label>
                <input
                  type="text"
                  required
                  value={regUsername}
                  onChange={(e) => setRegUsername(e.target.value)}
                  placeholder="sardor_dev"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Parol *</label>
                <div className="relative">
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••"
                    className="w-full px-3 py-2 pr-8 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute right-2 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-slate-300 font-medium mb-1">Tasdiqlash *</label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="••••••"
                    className="w-full px-3 py-2 pr-8 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-2 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Odamlikni Tasdiqlash (CAPTCHA) */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-indigo-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Odamlikni Tasdiqlash (Anti-Bot)
                </span>
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                  {captchaNum1} + {captchaNum2} = ?
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  required
                  value={captchaAnswer}
                  onChange={(e) => setCaptchaAnswer(e.target.value)}
                  placeholder="Hisob javobini yozing..."
                  className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={isHumanConfirmed}
                    onChange={(e) => setIsHumanConfirmed(e.target.checked)}
                    className="rounded border-slate-700 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Men robot emasman</span>
                </label>
              </div>
            </div>

            <button
              type="submit"
              disabled={regAge < 13}
              className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 disabled:opacity-40 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 mt-4"
            >
              <CheckCircle2 className="w-4 h-4" />
              Talaba Sifatida Boshlash
            </button>
          </form>
        )}
      </div>

      {showGoogleModal && (
        <GoogleAuthDialog
          onClose={() => setShowGoogleModal(false)}
          onSuccess={(user) => {
            setShowGoogleModal(false);
            onAuthSuccess(user);
            onClose();
          }}
        />
      )}
    </div>
  );
};
