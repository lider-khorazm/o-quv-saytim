import React, { useState } from 'react';
import {
  Crown,
  Bot,
  Sparkles,
  Send,
  Users,
  Award,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  FileText,
  Shield,
  Key,
  MessageSquare,
  BarChart3,
  RefreshCw,
  Cpu,
  Mail
} from 'lucide-react';
import { Student, Teacher, TestSubmissionResult, ExpelRequest, CourseStage } from '../types';
import { OWNER_PROFILE, OWNER_CREDENTIALS } from '../data/mockData';
import { askAdminJasur, askAdminNigora } from '../services/groqService';

interface AdminViewProps {
  teachers: Teacher[];
  students: Student[];
  testSubmissions: TestSubmissionResult[];
  expelRequests: ExpelRequest[];
  onAddTeacher: (teacher: Omit<Teacher, 'id' | 'studentIds' | 'rating' | 'activeSince'>) => void;
  onDeleteTeacher: (id: string) => void;
  onApproveUpgrade: (submissionId: string) => void;
  onResolveExpel: (requestId: string, approve: boolean) => void;
  onOpenGroupChat?: (teacherId: string) => void;
  onOpenGroqConfig?: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  teachers,
  students,
  testSubmissions,
  expelRequests,
  onAddTeacher,
  onDeleteTeacher,
  onApproveUpgrade,
  onResolveExpel,
  onOpenGroupChat,
  onOpenGroqConfig,
}) => {
  // Tabs: 'ai_command_center' (Boshqaruv & 2 AI Admin) | 'students' | 'submissions'
  const [activeTab, setActiveTab] = useState<'ai_command_center' | 'students' | 'submissions'>('ai_command_center');

  // Active AI Admin selected to give orders to
  const [selectedAiAdmin, setSelectedAiAdmin] = useState<'jasur' | 'nigora'>('jasur');

  // Command bar input
  const [commandInput, setCommandInput] = useState('');
  const [commandLoading, setCommandLoading] = useState(false);

  // Chat/History with Admin Jasur
  const [jasurMessages, setJasurMessages] = useState<{ role: 'user' | 'assistant'; text: string; time: string }[]>([
    {
      role: 'assistant',
      text: "Hurmatli Asoschi Olimjon aka (Lord)! Men sizning 1-raqamli yordamchingiz Admin Jasurman (Monitoring & Xavfsizlik). Platformadagi barcha 100 ta dars, o'quvchilar intizomi, COPPA 13+ yosh tekshiruvi va xavfsizlik nazoratim ostida. Qanday buyrug'ingiz bor?",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Chat/History with Admin Nigora
  const [nigoraMessages, setNigoraMessages] = useState<{ role: 'user' | 'assistant'; text: string; time: string }[]>([
    {
      role: 'assistant',
      text: "Assalomu alaykum, Boshliq Olimjon aka! Men sizning 2-raqamli yordamchingiz Admin Nigoraman (Akademik & XP Tahlili). Talabalarning to'plagan XP lari, ishlangan testlari, yiqilish foizlari va eng yaxshi natijalar tahlili bilan xizmatingizdaman!",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Calculated Real-Time Metrics
  const totalXp = students.reduce((acc, s) => acc + (s.xp || 0), 0);
  const totalLessonsDone = students.reduce((acc, s) => acc + (s.completedLessons?.length || 0), 0);
  const totalTestsTaken = testSubmissions.length;
  const passedTests = testSubmissions.filter((t) => t.percentage >= 70).length;
  const passRate = totalTestsTaken > 0 ? Math.round((passedTests / totalTestsTaken) * 100) : 85;

  const handleSendCommand = async (customCommand?: string) => {
    const cmd = (customCommand || commandInput).trim();
    if (!cmd || commandLoading) return;

    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setCommandLoading(true);
    setCommandInput('');

    if (selectedAiAdmin === 'jasur') {
      setJasurMessages((prev) => [...prev, { role: 'user', text: cmd, time }]);
      try {
        const res = await askAdminJasur({
          command: cmd,
          stats: {
            totalStudents: students.length,
            activeToday: students.length > 0 ? students.length : 1,
            completedStages: totalLessonsDone,
            testsTaken: totalTestsTaken,
            averageXp: students.length > 0 ? Math.round(totalXp / students.length) : 0,
          },
          chatHistory: jasurMessages,
        });

        const aiTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        setJasurMessages((prev) => [...prev, { role: 'assistant', text: res.text, time: aiTime }]);
      } catch {
        setJasurMessages((prev) => [
          ...prev,
          { role: 'assistant', text: "Buyruqni bajarishda tarmoq xatosi. Iltimos qaytadan yuboring.", time },
        ]);
      } finally {
        setCommandLoading(false);
      }
    } else {
      setNigoraMessages((prev) => [...prev, { role: 'user', text: cmd, time }]);
      try {
        const res = await askAdminNigora({
          command: cmd,
          stats: {
            totalStudents: students.length,
            totalXp: totalXp,
            testsTaken: totalTestsTaken,
            testPassRate: passRate,
            topPerformers: students.slice(0, 3).map((s) => `${s.name} (${s.xp} XP)`),
          },
          chatHistory: nigoraMessages,
        });

        const aiTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        setNigoraMessages((prev) => [...prev, { role: 'assistant', text: res.text, time: aiTime }]);
      } catch {
        setNigoraMessages((prev) => [
          ...prev,
          { role: 'assistant', text: "Buyruqni bajarishda tarmoq xatosi. Iltimos qaytadan yuboring.", time },
        ]);
      } finally {
        setCommandLoading(false);
      }
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Super Admin Top Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border border-purple-500/20 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4 sm:gap-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-purple-500 to-amber-500 p-0.5 shadow-xl">
              <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center text-amber-400">
                <Crown className="w-10 h-10 animate-bounce" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {OWNER_PROFILE.name} (Lord)
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Bosh Boshqaruvchi (Owner)
                </span>
              </div>
              <p className="text-slate-300 text-xs sm:text-sm mt-1 flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-purple-400" />
                <span className="font-mono text-purple-300">olimjonalimjonov12@gmail.com</span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-400">2 ta Groq AI Co-Adminiga bevosita buyruq beradi</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {onOpenGroqConfig && (
              <button
                onClick={onOpenGroqConfig}
                className="px-4 py-2.5 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 text-orange-300 text-xs font-semibold border border-orange-500/30 flex items-center gap-1.5 transition-colors"
              >
                <Key className="w-4 h-4 text-orange-400" />
                Groq AI Kaliti
              </button>
            )}
            {onOpenGroupChat && (
              <button
                onClick={() => onOpenGroupChat('t-1')}
                className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-lg shadow-purple-600/20 flex items-center gap-1.5 transition-all"
              >
                <MessageSquare className="w-4 h-4" />
                Umumiy Guruh Chati
              </button>
            )}
          </div>
        </div>

        {/* Live System Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Jami Ro'yxatdan O'tganlar</span>
            <span className="text-lg font-bold text-white">{students.length} talaba</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Jamlangan Umumiy XP</span>
            <span className="text-lg font-bold text-amber-400">{totalXp.toLocaleString()} XP</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Topshirilgan Testlar</span>
            <span className="text-lg font-bold text-emerald-400">{totalTestsTaken} ta</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Test O'tish Ko'rsatkichi</span>
            <span className="text-lg font-bold text-indigo-400">{passRate}%</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('ai_command_center')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === 'ai_command_center'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Cpu className="w-4 h-4" />
          AI Buyruqlar Markazi (2 ta Groq Admin)
        </button>
        <button
          onClick={() => setActiveTab('students')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === 'students'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          Talabalar Boshqaruvi ({students.length})
        </button>
        <button
          onClick={() => setActiveTab('submissions')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === 'submissions'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Award className="w-4 h-4" />
          Test Natijalari ({testSubmissions.length})
        </button>
      </div>

      {/* TAB 1: AI COMMAND CENTER (2 Groq Co-Admins under Lord Olimjon Alimjonov) */}
      {activeTab === 'ai_command_center' && (
        <div className="space-y-6">
          {/* Two Co-Admins Selector Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Admin 1: Jasur */}
            <button
              onClick={() => setSelectedAiAdmin('jasur')}
              className={`p-5 rounded-2xl border text-left transition-all relative overflow-hidden flex items-start gap-4 ${
                selectedAiAdmin === 'jasur'
                  ? 'bg-indigo-950/40 border-indigo-500 shadow-xl ring-2 ring-indigo-500/30'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
                <Shield className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white">Admin Jasur (Groq AI)</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30">
                    Xavfsizlik & Monitoring
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Boshqaruv mas'uliyati: Talabalar intizomi, o'tilgan 100 ta bosqich nazorati, COPPA 13+ yosh tekshiruvi va xavfsizlik auditlari.
                </p>
                <span className="text-[11px] text-indigo-400 font-semibold mt-2 inline-block">
                  Buyruq berish uchun tanlang →
                </span>
              </div>
            </button>

            {/* Admin 2: Nigora */}
            <button
              onClick={() => setSelectedAiAdmin('nigora')}
              className={`p-5 rounded-2xl border text-left transition-all relative overflow-hidden flex items-start gap-4 ${
                selectedAiAdmin === 'nigora'
                  ? 'bg-purple-950/40 border-purple-500 shadow-xl ring-2 ring-purple-500/30'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center shrink-0">
                <BarChart3 className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white">Admin Nigora (Groq AI)</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30">
                    Akademik & XP Tahlili
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Boshqaruv mas'uliyati: Jamlangan XP lar, ishlangan testlar soni, o'rtacha ballar, qoloq va yetakchi talabalar tahlili.
                </p>
                <span className="text-[11px] text-purple-400 font-semibold mt-2 inline-block">
                  Buyruq berish uchun tanlang →
                </span>
              </div>
            </button>
          </div>

          {/* Quick Command Action Buttons */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Boshliq Olimjon Alimjonov (Lord) Uchun Tezkor Buyruqlar:
            </h4>
            <div className="flex flex-wrap gap-2 text-xs">
              <button
                onClick={() => handleSendCommand("Bugungi to'liq kunlik hisobotni chiqar: ishlangan bosqichlar, jamlangan XP va testlar soni qancha?")}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                📊 Kunlik to'liq hisobotni so'rash
              </button>
              <button
                onClick={() => handleSendCommand("Eng ko'p xato qilingan testlar va yiqilgan talabalar ro'yxatini tahlil qil")}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                ⚠️ Qiyin testlar va xatolar hisoboti
              </button>
              <button
                onClick={() => handleSendCommand("Top 5 yetakchi talabalar va ularning to'plagan XP ballarini chiqar")}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                🏆 Top talabalar reytingi
              </button>
              <button
                onClick={() => handleSendCommand("Barcha talabalar uchun rag'batlantiruvchi haftalik chaqiruv xabarini tayyorla")}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                📢 Rag'batlantiruvchi xabar loyihasi
              </button>
            </div>
          </div>

          {/* Active AI Chat Console */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center border ${
                  selectedAiAdmin === 'jasur'
                    ? 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30'
                    : 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                }`}>
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    {selectedAiAdmin === 'jasur' ? 'Admin Jasur (Xavfsizlik & Monitoring)' : 'Admin Nigora (Akademik & XP Tahlili)'}
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                      Groq Llama 3.3
                    </span>
                  </h4>
                  <p className="text-xs text-slate-400">
                    Boshliq Olimjon Alimjonov buyrug'ini kutmoqda...
                  </p>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="p-4 space-y-4 max-h-[460px] overflow-y-auto">
              {(selectedAiAdmin === 'jasur' ? jasurMessages : nigoraMessages).map((m, idx) => (
                <div
                  key={idx}
                  className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                      m.role === 'user'
                        ? 'bg-purple-600 text-white rounded-br-none shadow-md'
                        : 'bg-slate-800/90 text-slate-200 border border-slate-700/60 rounded-bl-none shadow-sm'
                    }`}
                  >
                    <div className="whitespace-pre-wrap">{m.text}</div>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 px-1">{m.time}</span>
                </div>
              ))}

              {commandLoading && (
                <div className="flex items-center gap-2 text-xs text-purple-400 bg-purple-500/10 border border-purple-500/20 p-3 rounded-xl w-fit">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>
                    {selectedAiAdmin === 'jasur' ? 'Admin Jasur' : 'Admin Nigora'} buyruqni tahlil qilib, hisobot tayyorlamoqda...
                  </span>
                </div>
              )}
            </div>

            {/* Input Bar */}
            <form onSubmit={(e) => { e.preventDefault(); handleSendCommand(); }} className="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2">
              <input
                type="text"
                value={commandInput}
                onChange={(e) => setCommandInput(e.target.value)}
                placeholder={`${selectedAiAdmin === 'jasur' ? 'Admin Jasur' : 'Admin Nigora'}ga buyruq yoki topshiriq bering...`}
                className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              />
              <button
                type="submit"
                disabled={!commandInput.trim() || commandLoading}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md shrink-0"
              >
                <Send className="w-4 h-4" />
                <span>Buyruq Berish</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 2: Students List */}
      {activeTab === 'students' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white">Ro'yxatdan O'tgan Talabalar Nazorati</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase font-semibold">
                <tr>
                  <th className="p-3">Talaba</th>
                  <th className="p-3">Email & Yoshi</th>
                  <th className="p-3">Bosqich</th>
                  <th className="p-3">XP</th>
                  <th className="p-3">Darslar</th>
                  <th className="p-3">Jonlar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {students.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-850">
                    <td className="p-3 flex items-center gap-3">
                      <img src={s.avatar} alt={s.name} className="w-8 h-8 rounded-full object-cover" />
                      <span className="font-semibold text-white">{s.name} {s.surname}</span>
                    </td>
                    <td className="p-3">{s.email} • {s.age || 16} yosh</td>
                    <td className="p-3 uppercase font-bold text-purple-400">{s.stage}</td>
                    <td className="p-3 text-amber-400 font-bold">{s.xp} XP</td>
                    <td className="p-3">{s.completedLessons.length} / 100</td>
                    <td className="p-3 text-rose-400">{'❤️'.repeat(s.hearts !== undefined ? s.hearts : 3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Submissions */}
      {activeTab === 'submissions' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white">Topshirilgan Testlar Natijalari</h3>
          {testSubmissions.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">Hozircha birorta ham rasmiy test topshirilmagan.</p>
          ) : (
            <div className="space-y-3">
              {testSubmissions.map((sub) => (
                <div key={sub.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-white text-xs sm:text-sm">{sub.studentName} — {sub.stage.toUpperCase()}</p>
                    <p className="text-[11px] text-slate-400">{sub.submittedAt} • Test ID: {sub.testId}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    sub.percentage >= 70 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {sub.percentage}% {sub.percentage >= 70 ? "O'tdi" : "Yiqildi"}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
