import React from 'react';
import { Award, CheckCircle2, Download, Printer, X, ShieldCheck, Sparkles } from 'lucide-react';
import { CertificateData } from '../types';

interface CertificateModalProps {
  certificate: CertificateData;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ certificate, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between p-4 px-6 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Award className="w-4 h-4 text-amber-400" />
            <span>DevMaster Academy Rasmiy Sertifikati</span>
            <span className="text-slate-500">•</span>
            <span className="font-mono text-emerald-400">{certificate.serialNumber}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <Printer className="w-3.5 h-3.5" />
              Chop Etish / PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Body (Printable Design) */}
        <div className="p-8 sm:p-12 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-center relative overflow-hidden print:p-0 print:bg-white print:text-black">
          {/* Decorative Corner Borders */}
          <div className="absolute top-4 left-4 w-12 h-12 border-t-2 border-l-2 border-amber-400/60 rounded-tl-xl pointer-events-none" />
          <div className="absolute top-4 right-4 w-12 h-12 border-t-2 border-r-2 border-amber-400/60 rounded-tr-xl pointer-events-none" />
          <div className="absolute bottom-4 left-4 w-12 h-12 border-b-2 border-l-2 border-amber-400/60 rounded-bl-xl pointer-events-none" />
          <div className="absolute bottom-4 right-4 w-12 h-12 border-b-2 border-r-2 border-amber-400/60 rounded-br-xl pointer-events-none" />

          {/* Certificate Badge & Academy Header */}
          <div className="space-y-3">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-2xl shadow-amber-500/20">
              <div className="w-full h-full rounded-[22px] bg-slate-950 flex items-center justify-center text-amber-400">
                <Award className="w-10 h-10" />
              </div>
            </div>

            <h4 className="text-xs font-bold uppercase tracking-[0.25em] text-amber-400">
              DevMaster Academy • Xalqaro Dasturlash Maktabi
            </h4>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              SERTIFIKAT
            </h1>
            <p className="text-xs text-slate-400 uppercase tracking-widest">
              Muvaffaqiyatli Bitirganlik To'g'risida
            </p>
          </div>

          {/* Recipient */}
          <div className="my-8 space-y-2">
            <p className="text-xs sm:text-sm text-slate-300 italic">Ushbu hujjat tasdiqlaydiki,</p>
            <h2 className="text-2xl sm:text-3xl font-black text-amber-300 tracking-wide font-serif">
              {certificate.studentName}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed pt-2">
              DevMaster Academy platformasida <span className="font-bold text-white">"{certificate.title}"</span> talablarini muvaffaqiyatli tamomladi, murakkab amaliy test va vazifalarni <span className="text-emerald-400 font-bold">{certificate.scorePercentage}%</span> natija bilan yakunladi.
            </p>
          </div>

          {/* Skills Badges */}
          <div className="flex flex-wrap items-center justify-center gap-2 my-6 max-w-lg mx-auto">
            {certificate.skills.map((skill, i) => (
              <span
                key={i}
                className="px-3 py-1 rounded-full text-[11px] font-semibold bg-slate-800/80 text-slate-200 border border-slate-700/80 shadow-sm"
              >
                {skill}
              </span>
            ))}
          </div>

          {/* Signatures & Serial */}
          <div className="grid grid-cols-3 gap-4 pt-8 border-t border-slate-800/80 text-xs mt-6 items-end">
            <div className="text-left space-y-1">
              <p className="font-bold text-white">Olimjon Alimjonov (Lord)</p>
              <p className="text-[11px] text-slate-400">Platforma Asoschisi & Bosh Arxitektor</p>
              <div className="w-24 h-0.5 bg-amber-400/40 mt-1" />
            </div>

            {/* QR Code representation */}
            <div className="flex flex-col items-center justify-center">
              <div className="w-16 h-16 bg-white p-1 rounded-xl shadow-md flex items-center justify-center">
                <div className="w-full h-full border border-slate-900 flex flex-col items-center justify-center text-[8px] font-mono text-slate-900 font-bold">
                  <span>QR VERIFY</span>
                  <span className="text-[6px] text-slate-600">{certificate.serialNumber.slice(-6)}</span>
                </div>
              </div>
              <span className="text-[9px] text-slate-400 mt-1 font-mono">{certificate.serialNumber}</span>
            </div>

            <div className="text-right space-y-1">
              <p className="font-bold text-white">Berilgan sana: {certificate.issueDate}</p>
              <p className="text-[11px] text-emerald-400 font-semibold flex items-center justify-end gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Rasmiy Tasdiqlangan
              </p>
              <div className="w-24 h-0.5 bg-emerald-400/40 ml-auto mt-1" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
