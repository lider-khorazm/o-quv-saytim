import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, Mail, ArrowRight } from 'lucide-react';
import { loginWithGoogle } from '../services/storage';
import { AuthUser } from '../types';

interface GoogleAuthDialogProps {
  onClose: () => void;
  onSuccess: (user: AuthUser) => void;
}

export const GoogleAuthDialog: React.FC<GoogleAuthDialogProps> = ({ onClose, onSuccess }) => {
  const [customEmail, setCustomEmail] = useState('');
  const [customName, setCustomName] = useState('');
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSelectAccount = (email: string, name: string) => {
    setLoading(true);
    setTimeout(() => {
      const res = loginWithGoogle(email, name);
      if (res.success && res.user) {
        onSuccess(res.user);
        onClose();
      }
      setLoading(false);
    }, 500);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail.trim() || !customName.trim()) return;
    handleSelectAccount(customEmail.trim(), customName.trim());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-white text-slate-800 rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
        {/* Google Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <svg className="w-6 h-6" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <div>
              <h3 className="font-bold text-sm text-slate-900">Google orqali kirish</h3>
              <p className="text-[11px] text-slate-500">DevMaster Academy ga ulanish</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600">
            Davom etish uchun Google hisobingizni tanlang yoki yangisini kiriting:
          </p>

          {/* Quick Primary Option: Olimjon Alimjonov (Owner) */}
          <button
            onClick={() => handleSelectAccount('olimjonalimjonov12@gmail.com', 'Olimjon Alimjonov (Lord)')}
            disabled={loading}
            className="w-full p-3.5 rounded-2xl border border-purple-200 bg-purple-50 hover:bg-purple-100/80 transition-all text-left flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-purple-600 text-white font-bold flex items-center justify-center text-sm shadow-sm">
                OA
              </div>
              <div>
                <p className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                  Olimjon Alimjonov
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-200 text-purple-800 font-semibold">
                    Owner Admin
                  </span>
                </p>
                <p className="text-[11px] text-slate-600">olimjonalimjonov12@gmail.com</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-purple-600 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Quick Demo Student Option */}
          <button
            onClick={() => handleSelectAccount('shaxzod.talaba@gmail.com', 'Shaxzod Bek')}
            disabled={loading}
            className="w-full p-3.5 rounded-2xl border border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-slate-100 transition-all text-left flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-sm shadow-sm">
                SB
              </div>
              <div>
                <p className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                  Shaxzod Bek
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-medium">
                    Talaba
                  </span>
                </p>
                <p className="text-[11px] text-slate-500">shaxzod.talaba@gmail.com</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Custom Google Account Toggle */}
          {!showCustomInput ? (
            <button
              type="button"
              onClick={() => setShowCustomInput(true)}
              className="w-full py-2.5 text-xs text-indigo-600 hover:text-indigo-700 font-semibold text-center hover:underline"
            >
              + Boshqa Google hisobini kiritish
            </button>
          ) : (
            <form onSubmit={handleCustomSubmit} className="pt-2 border-t border-slate-100 space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Ismingiz:
                </label>
                <input
                  type="text"
                  required
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="Masalan: Sardor Komilov"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Gmail manzilingiz:
                </label>
                <input
                  type="email"
                  required
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  placeholder="ismingiz@gmail.com"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
              >
                Ushbu Google Hisobi Bilan Kirish
              </button>
            </form>
          )}

          {/* Security footnote */}
          <div className="pt-2 text-[10px] text-slate-400 text-center flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Google xavfsiz autentifikatsiya protokoli (13+ yosh tasdiqlangan)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
