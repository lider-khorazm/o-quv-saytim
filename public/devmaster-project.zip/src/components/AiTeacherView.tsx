import React, { useState } from 'react';
import {
  GraduationCap,
  Sparkles,
  Send,
  Users,
  CheckCircle2,
  Clock,
  BookOpen,
  Award,
  Search,
  MessageSquare,
  FileCode,
  ShieldCheck,
  RefreshCw,
  Key
} from 'lucide-react';
import { Student, CourseStage } from '../types';
import { askAiTeacher } from '../services/groqService';

interface AiTeacherViewProps {
  students: Student[];
  onOpenCreateTestModal?: (student: Student, stage: CourseStage) => void;
  onOpenGroupChat?: (teacherId: string) => void;
  onOpenGroqConfig?: () => void;
}

export const AiTeacherView: React.FC<AiTeacherViewProps> = ({
  students,
  onOpenCreateTestModal,
  onOpenGroupChat,
  onOpenGroqConfig,
}) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'monitoring' | 'chat' | 'reviews'>('monitoring');
  const [searchQuery, setSearchQuery] = useState('');

  // AI Chat with Ustoz Temur
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; text: string; time: string }[]>([
    {
      role: 'assistant',
      text: "Assalomu alaykum! Men Ustoz Temurman — DevMaster Academy bosh AI murabbiyiman (Groq Llama 3.3 70B). Barcha talabalarning o'rganish tezligini, test natijalarini va chatlardagi faolligini nazorat qilaman. Qaysi talabani tahlil qilaylik yoki qanday dars topshirig'ini yarataylik?",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.surname.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedStudent = students.find((s) => s.id === selectedStudentId) || students[0];

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || loading) return;

    const userText = inputMessage.trim();
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setMessages((prev) => [...prev, { role: 'user', text: userText, time }]);
    setInputMessage('');
    setLoading(true);

    try {
      const res = await askAiTeacher({
        action: 'chat',
        studentName: selectedStudent ? `${selectedStudent.name} ${selectedStudent.surname}` : 'Barcha talabalar',
        studentStage: selectedStudent ? selectedStudent.stage : 'fullstack',
        userPrompt: userText,
        chatHistory: messages,
      });

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: res.text, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: "Tarmoq xatosi. Iltimos qaytadan urinib ko'ring.",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 border border-emerald-500/20 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4 sm:gap-5">
            <div className="relative">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400/40 flex items-center justify-center text-emerald-400 shadow-xl overflow-hidden">
                <GraduationCap className="w-10 h-10 animate-pulse" />
              </div>
              <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-2 border-slate-900 flex items-center justify-center text-[10px] text-white font-bold">
                ✓
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Ustoz Temur AI
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  Groq Pedagogik Murabbiy
                </span>
              </div>
              <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
                Avtomatlashtirilgan o'qitish tizimi: 100 ta mavzu bo'yicha talabalarni o'qitadi, guruh chatlarini nazorat qiladi, kod xatolarini tahlil qiladi va imtihonlarni boshqaradi.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {onOpenGroqConfig && (
              <button
                onClick={onOpenGroqConfig}
                className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                <Key className="w-3.5 h-3.5 text-orange-400" />
                Groq Kaliti
              </button>
            )}
            {onOpenGroupChat && (
              <button
                onClick={() => onOpenGroupChat('t-1')}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 transition-all"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                Guruh Chatiga Kirish
              </button>
            )}
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Nazoratdagi Talabalar</span>
            <span className="text-lg font-bold text-white">{students.length} nafar</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">O'qitish Qamrovi</span>
            <span className="text-lg font-bold text-emerald-400">100 ta Katta Dars</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Texnologiyalar</span>
            <span className="text-lg font-bold text-indigo-400">Frontend + Backend + DB</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Ish Rejimi</span>
            <span className="text-lg font-bold text-amber-400">24/7 Avtomatik</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('monitoring')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === 'monitoring'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          Talabalar Monitoringi ({students.length})
        </button>
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === 'chat'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          Ustoz Temur bilan Muloqot (AI)
        </button>
      </div>

      {/* TAB 1: Monitoring */}
      {activeTab === 'monitoring' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Students List */}
          <div className="lg:col-span-1 space-y-3 bg-slate-900 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Talabalar Ro'yxati
              </h3>
              <span className="text-xs text-emerald-400">{filteredStudents.length} ta</span>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Qidiruv (ism, login)..."
                className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="space-y-1.5 max-h-[500px] overflow-y-auto pr-1">
              {filteredStudents.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-500">
                  Hozircha yangi talaba ro'yxatdan o'tmagan.
                </div>
              ) : (
                filteredStudents.map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStudentId(st.id)}
                    className={`w-full p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                      selectedStudent?.id === st.id
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-white'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    <img
                      src={st.avatar || 'https://images.unsplash.com/photo-1535713875002?w=100'}
                      alt={st.name}
                      className="w-9 h-9 rounded-full object-cover border border-slate-700 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-xs truncate">
                        {st.name} {st.surname}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                        <span className="uppercase text-emerald-400 font-bold">{st.stage}</span>
                        <span>•</span>
                        <span>{st.xp} XP</span>
                        <span>•</span>
                        <span>{st.completedLessons.length} dars</span>
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Right: Selected Student Details & AI Advice */}
          <div className="lg:col-span-2 space-y-4">
            {selectedStudent ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
                {/* Student Header */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-4">
                    <img
                      src={selectedStudent.avatar}
                      alt={selectedStudent.name}
                      className="w-14 h-14 rounded-2xl object-cover border border-slate-700"
                    />
                    <div>
                      <h2 className="text-lg font-bold text-white">
                        {selectedStudent.name} {selectedStudent.surname}
                      </h2>
                      <p className="text-xs text-slate-400">
                        @{selectedStudent.username} • {selectedStudent.email} • Yoshi: {selectedStudent.age || 16}
                      </p>
                    </div>
                  </div>

                  {onOpenCreateTestModal && (
                    <button
                      onClick={() => onOpenCreateTestModal(selectedStudent, selectedStudent.stage)}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md"
                    >
                      <FileCode className="w-3.5 h-3.5" />
                      Yangi Test ID Yaratish
                    </button>
                  )}
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-[11px] text-slate-400 block mb-1">To'plangan XP</span>
                    <span className="text-base font-bold text-amber-400">{selectedStudent.xp} XP</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-[11px] text-slate-400 block mb-1">Darslar</span>
                    <span className="text-base font-bold text-emerald-400">
                      {selectedStudent.completedLessons.length} / 100
                    </span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-[11px] text-slate-400 block mb-1">Qolgan Jonlar</span>
                    <span className="text-base font-bold text-rose-400">
                      {'❤️'.repeat(selectedStudent.hearts !== undefined ? selectedStudent.hearts : 3) || '💔'}
                    </span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-[11px] text-slate-400 block mb-1">Sertifikatlar</span>
                    <span className="text-base font-bold text-indigo-400">
                      {selectedStudent.certificates?.length || 0} ta
                    </span>
                  </div>
                </div>

                {/* AI Pedagogical Assessment */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 via-slate-950 to-indigo-500/10 border border-emerald-500/30 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    Ustoz Temurning Pedagogik Xulosasi:
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {selectedStudent.completedLessons.length >= 25
                      ? `Talaba ${selectedStudent.name} juda faol va 25+ dan ortiq mavzuni muvaffaqiyatli topshirgan. Uning keyingi qadami — Backend va Baza darslarini boshlash va birinchi sertifikatiga erishishdir!`
                      : `Talaba ${selectedStudent.name} o'rganishni yaxshi boshlagan. Unga ko'proq kod mashqlarini yozish va dars oxiridagi testlarni 70% dan yuqori yechib, XP to'plashni davom ettirish tavsiya etiladi.`}
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-12 text-center text-slate-500 bg-slate-900 border border-slate-800 rounded-2xl">
                Iltimos, chap tomondan talabani tanlang.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: AI Teacher Chat */}
      {activeTab === 'chat' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Ustoz Temur bilan Muloqot</h4>
                <p className="text-xs text-slate-400">Dars rejasi, talaba xatolari yoki pedagogik maslahatlar haqida so'rang</p>
              </div>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Llama 3.3 70B
            </span>
          </div>

          <div className="p-4 space-y-3.5 max-h-[450px] overflow-y-auto">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-emerald-600 text-white rounded-br-none shadow-md'
                      : 'bg-slate-800/90 text-slate-200 border border-slate-700/60 rounded-bl-none shadow-sm'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{m.text}</div>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1">{m.time}</span>
              </div>
            ))}

            {loading && (
              <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl w-fit">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Ustoz Temur o'ylamoqda...</span>
              </div>
            )}
          </div>

          <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ustoz Temurga savol yoki buyruq yozing..."
              className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim() || loading}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Yuborish</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
