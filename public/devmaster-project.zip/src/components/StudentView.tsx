import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Code2,
  Play,
  RotateCcw,
  Sparkles,
  Award,
  Clock,
  ChevronRight,
  HelpCircle,
  AlertCircle,
  ExternalLink,
  Laptop,
  Check,
  Zap,
  Target,
  Flame,
  FileCode,
  ShieldCheck,
  Send,
  MessageSquare,
  Search,
  SlidersHorizontal,
  Bot,
  Heart,
  Gamepad2,
  Terminal,
  Database,
  Server,
  Layers,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Student, Teacher, TestSubmissionResult, CourseStage, Lesson, CertificateData } from '../types';
import { LESSONS } from '../data/mockData';
import { recordGameXp, getStudentCertificates } from '../services/storage';
import { LessonSlideDeck } from './LessonSlideDeck';
import { StudentAiAssistant } from './StudentAiAssistant';
import { LessonQuizModal } from './LessonQuizModal';
import { CertificateModal } from './CertificateModal';

interface StudentViewProps {
  student: Student | null;
  teacher: Teacher | null;
  testSubmissions: TestSubmissionResult[];
  onOpenTestIdModal?: (initialId?: string) => void;
  onOpenFinalExamModal?: () => void;
  onOpenGroupChat?: (teacherId: string) => void;
  onCompleteLesson: (lessonId: string) => void;
  onOpenRegisterModal?: () => void;
  onOpenGroqConfig?: () => void;
}

export const StudentView: React.FC<StudentViewProps> = ({
  student,
  teacher,
  testSubmissions,
  onOpenTestIdModal,
  onOpenFinalExamModal,
  onOpenGroupChat,
  onCompleteLesson,
  onOpenRegisterModal,
  onOpenGroqConfig,
}) => {
  // Current Track Filter
  const [selectedTrack, setSelectedTrack] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Active Lesson Modal
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [lessonMode, setLessonMode] = useState<'textbook' | 'slides' | 'tryit' | 'assistant'>('textbook');

  // Try-It Studio State
  const [userCode, setUserCode] = useState('');
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const [isCodeRunning, setIsCodeRunning] = useState(false);

  // Lesson Quiz Modal
  const [quizLesson, setQuizLesson] = useState<Lesson | null>(null);

  // Certificate Modal
  const [viewingCertificate, setViewingCertificate] = useState<CertificateData | null>(null);

  // Floating Yordamchi AI
  const [showFloatingAi, setShowFloatingAi] = useState(false);

  // Coding Game State (Mini Interactive Code Challenger)
  const [showGameModal, setShowGameModal] = useState(false);
  const [gameScore, setGameScore] = useState(0);

  const fallbackStudent: Student = {
    id: 'guest',
    name: 'Mehmon',
    surname: 'Talaba',
    username: 'mehmon_dev',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
    phone: '+998 90 000 00 00',
    email: 'mehmon@devmaster.uz',
    stage: 'html',
    xp: 0,
    rank: 1,
    coins: 20,
    hearts: 3,
    teacherId: 'ai-teacher-temur',
    completedLessons: [],
    lastActive: 'Hozir',
    joinedDate: '2026-10-27',
  };

  const currentStudent = student || fallbackStudent;
  const certificates = getStudentCertificates(currentStudent.id);

  // Tracks Configuration
  const tracks = [
    { id: 'all', name: 'Barcha 100 ta Mavzu', count: 100, icon: Layers },
    { id: 'html', name: 'HTML5 & Semantika', count: 15, icon: FileCode },
    { id: 'css', name: 'CSS3 & Dizayn', count: 15, icon: Laptop },
    { id: 'javascript', name: 'JavaScript ES6+', count: 20, icon: Zap },
    { id: 'typescript', name: 'TypeScript & React', count: 15, icon: Code2 },
    { id: 'backend', name: 'Backend & Express', count: 15, icon: Server },
    { id: 'database', name: "Ma'lumotlar Bazasi (SQL)", count: 12, icon: Database },
    { id: 'fullstack', name: 'Full-Stack & DevOps', count: 8, icon: ShieldCheck },
  ];

  const filteredLessons = LESSONS.filter((l) => {
    const matchTrack = selectedTrack === 'all' || l.stage === selectedTrack;
    const matchSearch =
      l.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchTrack && matchSearch;
  });

  const handleOpenLesson = (lesson: Lesson) => {
    setActiveLesson(lesson);
    setUserCode(lesson.starterCode);
    setConsoleOutput([]);
    setLessonMode('textbook');
  };

  // Run user code in Try-It
  const handleRunCode = () => {
    if (!activeLesson) return;
    setIsCodeRunning(true);
    setConsoleOutput([]);

    setTimeout(() => {
      try {
        const logs: string[] = [];
        const customConsole = {
          log: (...args: any[]) => {
            logs.push(args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' '));
          },
          error: (...args: any[]) => {
            logs.push('❌ Xatolik: ' + args.join(' '));
          },
        };

        const fn = new Function('console', userCode);
        fn(customConsole);

        if (logs.length === 0) {
          logs.push('Kod xatosiz bajarildi (hech qanday console.log chiqarilmadi).');
        }
        setConsoleOutput(logs);
      } catch (err: any) {
        setConsoleOutput([`❌ Kod bajarilishida xatolik: ${err.message}`]);
      } finally {
        setIsCodeRunning(false);
      }
    }, 200);
  };

  // Quick Coding Game (+50 XP)
  const handlePlayMiniGame = (won: boolean) => {
    if (won) {
      const earned = 50;
      recordGameXp(currentStudent.id, 'Syntax Speed Game', earned);
      setGameScore((prev) => prev + earned);
      try {
        confetti({ particleCount: 80, spread: 60, origin: { y: 0.7 } });
      } catch {}
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Student Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4 sm:gap-5">
            <img
              src={currentStudent.avatar}
              alt={currentStudent.name}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-indigo-500/40 shadow-xl"
            />
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                  {currentStudent.name} {currentStudent.surname}
                </h1>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold uppercase">
                  {currentStudent.stage} Yo'nalishi
                </span>
              </div>
              <p className="text-slate-400 text-xs sm:text-sm mt-1">
                @{currentStudent.username} • Yoshi: {currentStudent.age || 16} • Murabbiy: <span className="text-emerald-400 font-semibold">Ustoz Temur (AI)</span>
              </p>
            </div>
          </div>

          {/* Student Status Bar */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center gap-2">
              <span className="text-xs text-slate-400">Jonlar:</span>
              <span className="text-sm font-bold text-rose-400 tracking-wider">
                {'❤️'.repeat(currentStudent.hearts !== undefined ? currentStudent.hearts : 3) || '💔'}
              </span>
            </div>

            <div className="px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400" />
              <span className="text-sm font-black text-amber-400">{currentStudent.xp} XP</span>
            </div>

            <button
              onClick={() => setShowGameModal(true)}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/20"
            >
              <Gamepad2 className="w-4 h-4" />
              Dasturlash O'yini (+XP)
            </button>

            {onOpenGroupChat && (
              <button
                onClick={() => onOpenGroupChat('t-1')}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all shadow-md"
              >
                <MessageSquare className="w-4 h-4" />
                Guruh Chati
              </button>
            )}
          </div>
        </div>

        {/* Quick Info Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">O'tilgan Darslar</span>
            <span className="text-base font-bold text-emerald-400">
              {currentStudent.completedLessons.length} / 100 dars
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">XP Manbai</span>
            <span className="text-base font-bold text-amber-400">Faqat Test & O'yindan</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Sertifikatlar</span>
            <span className="text-base font-bold text-indigo-400">{certificates.length} ta mavjud</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Shaxsiy Yordamchi</span>
            <span className="text-base font-bold text-purple-400">"Yordamchi" (Groq AI)</span>
          </div>
        </div>
      </div>

      {/* Certificates Banner if student has any */}
      {certificates.length > 0 && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-purple-500/10 to-indigo-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 shrink-0">
              <Award className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                Sizning Rasmiy Sertifikatlaringiz ({certificates.length} ta)
              </h3>
              <p className="text-xs text-slate-300">
                Muvaffaqiyatli tamomlagan yo'nalishlaringiz bo'yicha unikal QR-kodli sertifikatlar
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {certificates.map((cert) => (
              <button
                key={cert.id}
                onClick={() => setViewingCertificate(cert)}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                <Award className="w-3.5 h-3.5" />
                {cert.type === 'frontend' ? 'Frontend' : cert.type === 'backend' ? 'Backend & DB' : 'Full-Stack'}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Tracks Selector Navigation */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full scrollbar-none">
            {tracks.map((t) => {
              const Icon = t.icon;
              const isActive = selectedTrack === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setSelectedTrack(t.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 whitespace-nowrap transition-all border ${
                    isActive
                      ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{t.name}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-md ${
                    isActive ? 'bg-indigo-700 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {t.count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Search bar */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="100 ta dars ichidan qidiruv..."
              className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Lessons Grid (100 Lessons) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredLessons.map((lesson) => {
            const isCompleted = currentStudent.completedLessons.includes(lesson.id);
            const score = currentStudent.quizScores?.[lesson.id];

            return (
              <div
                key={lesson.id}
                onClick={() => handleOpenLesson(lesson)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between group ${
                  isCompleted
                    ? 'bg-emerald-950/20 border-emerald-500/30 hover:border-emerald-500/50'
                    : 'bg-slate-900/90 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                      {lesson.trackCategory || lesson.stage}
                    </span>
                    {isCompleted ? (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                        <CheckCircle2 className="w-3 h-3" />
                        {score ? `${score}%` : "O'tildi"}
                      </span>
                    ) : (
                      <span className="text-[11px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                        +{lesson.xpReward || 60} XP
                      </span>
                    )}
                  </div>

                  <h3 className="font-bold text-xs sm:text-sm text-white group-hover:text-indigo-400 transition-colors line-clamp-2">
                    {lesson.title}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {lesson.summary}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {lesson.duration}
                  </span>
                  <span className="text-indigo-400 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center">
                    Darsni O'rganish →
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ======================= LESSON VIEWER MODAL ======================= */}
      {activeLesson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-5xl h-[92vh] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base sm:text-lg font-bold text-white">
                      {activeLesson.title}
                    </h2>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold uppercase">
                      {activeLesson.stage}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 truncate max-w-md">{activeLesson.summary}</p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setQuizLesson(activeLesson)}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition-all"
                >
                  <HelpCircle className="w-4 h-4" />
                  <span>Test Topshirish (+{activeLesson.xpReward || 60} XP)</span>
                </button>
                <button
                  onClick={() => setActiveLesson(null)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Mode Switcher Tabs */}
            <div className="px-6 py-2 bg-slate-950 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
              <button
                onClick={() => setLessonMode('textbook')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  lessonMode === 'textbook'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                To'liq Konspekt (Darslik)
              </button>
              <button
                onClick={() => setLessonMode('slides')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  lessonMode === 'slides'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Laptop className="w-3.5 h-3.5" />
                Interfaol Slaydlar (Taqdimot)
              </button>
              <button
                onClick={() => setLessonMode('tryit')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  lessonMode === 'tryit'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                Try-It Studio (Jonli Kod Sinovi)
              </button>
              <button
                onClick={() => setLessonMode('assistant')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  lessonMode === 'assistant'
                    ? 'bg-purple-600 text-white'
                    : 'text-purple-400 hover:text-purple-300 hover:bg-purple-500/10'
                }`}
              >
                <Bot className="w-3.5 h-3.5" />
                Yordamchi AI Repetitori
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* TAB 1: TEXTBOOK (Comprehensive 600+ words deep study) */}
              {lessonMode === 'textbook' && (
                <div className="max-w-4xl mx-auto space-y-6 text-slate-200">
                  {/* Deep Explanation */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-400" />
                      Mavzuning To'liq Tahlili va Nazariyasi
                    </h3>
                    {activeLesson.deepExplanation?.map((paragraph, idx) => (
                      <p key={idx} className="text-sm leading-relaxed text-slate-300">
                        {paragraph}
                      </p>
                    ))}
                  </div>

                  {/* Code Example */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Standart Kod Namunasi:
                    </h4>
                    <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-300 overflow-x-auto">
                      {activeLesson.codeExample}
                    </pre>
                  </div>

                  {/* Common Mistakes */}
                  {activeLesson.commonMistakes && activeLesson.commonMistakes.length > 0 && (
                    <div className="space-y-3 p-5 rounded-2xl bg-slate-950 border border-slate-800">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4" />
                        Ko'p Uchraydigan Xatolar Tahlili (Bad vs Good):
                      </h4>
                      {activeLesson.commonMistakes.map((cm, i) => (
                        <div key={i} className="space-y-2 text-xs">
                          <p className="text-slate-300">{cm.explanation}</p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <pre className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/30 text-rose-300 font-mono">
                              {cm.badCode}
                            </pre>
                            <pre className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-300 font-mono">
                              {cm.goodCode}
                            </pre>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Interview Questions */}
                  {activeLesson.interviewQuestions && activeLesson.interviewQuestions.length > 0 && (
                    <div className="space-y-3 p-5 rounded-2xl bg-slate-950 border border-slate-800">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-2">
                        <Award className="w-4 h-4" />
                        Ish Suhbatlarida (Interview) Tushadigan Savol:
                      </h4>
                      {activeLesson.interviewQuestions.map((iq, i) => (
                        <div key={i} className="space-y-1 text-xs">
                          <p className="font-bold text-white">Savol: {iq.question}</p>
                          <p className="text-slate-300 pl-3 border-l-2 border-indigo-500">
                            Javob: {iq.answer}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Bottom Quiz Callout */}
                  <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-500/20 via-slate-950 to-indigo-500/20 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white">Nazariyani o'qib bo'ldingizmi?</h4>
                      <p className="text-xs text-slate-300 mt-0.5">
                        Test topshirib kamida 70% to'plang va +{activeLesson.xpReward || 60} XP ga ega bo'ling!
                      </p>
                    </div>
                    <button
                      onClick={() => setQuizLesson(activeLesson)}
                      className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md"
                    >
                      <HelpCircle className="w-4 h-4" />
                      Testni Boshlash
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 2: SLIDES */}
              {lessonMode === 'slides' && (
                <div className="h-full">
                  <LessonSlideDeck
                    slides={activeLesson.slides || []}
                    lessonTitle={activeLesson.title}
                    stage={activeLesson.stage}
                    fallbackSummary={activeLesson.summary}
                    fallbackCode={activeLesson.codeExample}
                    onOpenTryIt={() => setLessonMode('tryit')}
                  />
                </div>
              )}

              {/* TAB 3: TRY-IT STUDIO */}
              {lessonMode === 'tryit' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
                  {/* Code Editor */}
                  <div className="flex flex-col h-[480px] bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
                    <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-900">
                      <span className="text-xs font-mono text-slate-300 flex items-center gap-1.5">
                        <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                        Try-It Muharriri
                      </span>
                      <button
                        onClick={handleRunCode}
                        disabled={isCodeRunning}
                        className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all shadow-md"
                      >
                        <Play className="w-3.5 h-3.5" />
                        Ishga Tushirish
                      </button>
                    </div>
                    <textarea
                      value={userCode}
                      onChange={(e) => setUserCode(e.target.value)}
                      className="flex-1 p-4 bg-slate-950 text-white font-mono text-xs resize-none focus:outline-none"
                      placeholder="Kodingizni shu yerga yozing..."
                    />
                  </div>

                  {/* Output Terminal */}
                  <div className="flex flex-col h-[480px] bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
                    <div className="p-3 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
                      <span className="text-xs font-mono text-slate-300 flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                        Konsol Natijasi
                      </span>
                      <button
                        onClick={() => setConsoleOutput([])}
                        className="text-[11px] text-slate-400 hover:text-white"
                      >
                        Tozalash
                      </button>
                    </div>
                    <div className="flex-1 p-4 font-mono text-xs text-slate-300 overflow-y-auto space-y-1">
                      {consoleOutput.length === 0 ? (
                        <p className="text-slate-500 italic">Natijani ko'rish uchun "Ishga Tushirish" tugmasini bosing.</p>
                      ) : (
                        consoleOutput.map((log, i) => <div key={i}>{log}</div>)
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: YORDAMCHI AI */}
              {lessonMode === 'assistant' && (
                <div className="max-w-2xl mx-auto h-[500px]">
                  <StudentAiAssistant
                    currentLessonTitle={activeLesson.title}
                    currentLessonStage={activeLesson.stage}
                    currentCodeSnippet={userCode}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================= LESSON QUIZ MODAL ======================= */}
      {quizLesson && (
        <LessonQuizModal
          lesson={quizLesson}
          studentId={currentStudent.id}
          onClose={() => setQuizLesson(null)}
          onQuizSuccess={(earnedXp, newCert) => {
            onCompleteLesson(quizLesson.id);
            if (newCert) {
              setViewingCertificate(newCert);
            }
          }}
        />
      )}

      {/* ======================= CERTIFICATE VIEWER MODAL ======================= */}
      {viewingCertificate && (
        <CertificateModal
          certificate={viewingCertificate}
          onClose={() => setViewingCertificate(null)}
        />
      )}

      {/* ======================= CODING MINI-GAME MODAL ======================= */}
      {showGameModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center space-y-5">
            <button
              onClick={() => setShowGameModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/30">
              <Gamepad2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-white">Dasturlash Tezlik Sinovi (+50 XP)</h3>
              <p className="text-xs text-slate-400 mt-1">
                To'g'ri javobni tanlang va qimmatli XP to'plang!
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-left space-y-3">
              <p className="text-xs text-slate-300 font-semibold">
                Savol: Qaysi buyruq yordamida JavaScript-da asinxron funksiya e'lon qilinadi?
              </p>
              <div className="space-y-2 text-xs">
                <button
                  onClick={() => {
                    handlePlayMiniGame(true);
                    setShowGameModal(false);
                  }}
                  className="w-full p-2.5 rounded-xl bg-slate-900 hover:bg-emerald-600/30 border border-slate-800 hover:border-emerald-500 text-white transition-colors text-left"
                >
                  A) async function getData() {} (To'g'ri)
                </button>
                <button
                  onClick={() => {
                    handlePlayMiniGame(false);
                    setShowGameModal(false);
                  }}
                  className="w-full p-2.5 rounded-xl bg-slate-900 hover:bg-rose-600/30 border border-slate-800 text-slate-400 text-left"
                >
                  B) sync wait function() {}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
