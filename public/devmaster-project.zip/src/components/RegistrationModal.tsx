import React, { useState } from 'react';
import {
  UserPlus,
  Sparkles,
  CheckCircle2,
  Users,
  Eye,
  EyeOff,
  Lock,
  ShieldCheck,
  AlertCircle,
  Calendar,
  X,
  Bot
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Teacher, Student, AuthUser } from '../types';
import { registerStudent } from '../services/storage';
import { GoogleAuthDialog } from './GoogleAuthDialog';

interface RegistrationModalProps {
  onClose: () => void;
  onRegistered: (newStudent: Student, assignedTeacher: Teacher | null) => void;
  onGoogleSuccess?: (user: AuthUser) => void;
}

export const RegistrationModal: React.FC<RegistrationModalProps> = ({
  onClose,
  onRegistered,
  onGoogleSuccess,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    username: '',
    password: '',
    confirmPassword: '',
    phone: '+998 ',
    email: '',
    age: 16,
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showGoogleModal, setShowGoogleModal] = useState(false);

  // Odamlikni tasdiqlash (CAPTCHA)
  const [captchaNum1] = useState(Math.floor(Math.random() * 8) + 2);
  const [captchaNum2] = useState(Math.floor(Math.random() * 8) + 1);
  const [captchaAnswer, setCaptchaAnswer] = useState('');
  const [isHumanConfirmed, setIsHumanConfirmed] = useState(false);

  const [assignedResult, setAssignedResult] = useState<{
    student: Student;
    teacher: Teacher | null;
  } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // 1. Yosh tekshiruvi (Kamida 13 yosh)
    if (!formData.age || Number(formData.age) < 13) {
      setErrorMessage("⚠️ Xavfsizlik qoidalariga (COPPA) asosan, platformadan faqat 13 yosh va undan kattalar ro'yxatdan o'tishi mumkin!");
      return;
    }

    // 2. Odamlikni tasdiqlash tekshiruvi
    const expected = captchaNum1 + captchaNum2;
    if (parseInt(captchaAnswer) !== expected || !isHumanConfirmed) {
      setErrorMessage(`⚠️ Odamlikni tasdiqlash xatosi: Iltimos, "${captchaNum1} + ${captchaNum2} = ?" hisobini to'g'ri kiriting va katakchani belgilang!`);
      return;
    }

    if (!formData.name.trim() || !formData.surname.trim()) {
      setErrorMessage("Iltimos, ism va familiyangizni to'liq kiriting!");
      return;
    }

    if (!formData.username.trim()) {
      setErrorMessage("Iltimos, login (username) tanlang!");
      return;
    }

    if (!formData.password || formData.password.length < 4) {
      setErrorMessage("Parol kamida 4 ta belgidan iborat bo'lishi shart!");
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setErrorMessage("Parollar bir-biriga mos kelmadi! Iltimos, qayta tekshiring.");
      return;
    }

    const username = formData.username.trim().toLowerCase();
    try {
      const res = registerStudent({
        name: formData.name.trim(),
        surname: formData.surname.trim(),
        username: username,
        password: formData.password,
        phone: formData.phone.trim(),
        email: formData.email.trim(),
        age: Number(formData.age),
      });

      setAssignedResult(res);
      onRegistered(res.student, res.teacher);

      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#06b6d4', '#6366f1', '#10b981', '#f59e0b'],
        });
      } catch (err) {
        console.log('Confetti err:', err);
      }
    } catch (err: any) {
      setErrorMessage(err.message || "Ro'yxatdan o'tishda xatolik yuz berdi");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {!assignedResult ? (
          <div>
            <div className="text-center mb-5">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto mb-2 border border-cyan-500/30">
                <UserPlus className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Talaba Bo'lib Ro'yxatdan O'tish
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                100 ta dars, interfaol slaydlar va avtomatlashgan AI murabbiy bilan o'rganing!
              </p>
            </div>

            {/* Google Sign-in Button */}
            <div className="mb-4">
              <button
                type="button"
                onClick={() => setShowGoogleModal(true)}
                className="w-full py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-800 rounded-xl font-semibold text-xs flex items-center justify-center gap-2.5 shadow-md transition-colors border border-slate-200"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                Google orqali 1-soniyada ro'yxatdan o'tish
              </button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-800" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-slate-900 px-3 text-slate-500 font-medium">yoki an'anaviy shaklda</span>
                </div>
              </div>
            </div>

            {errorMessage && (
              <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Ism *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Sardor"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Familiya *</label>
                  <input
                    type="text"
                    required
                    value={formData.surname}
                    onChange={(e) => setFormData({ ...formData, surname: e.target.value })}
                    placeholder="Komilov"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>

              {/* Age & Phone */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-medium mb-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                    Yoshingiz * (13+)
                  </label>
                  <input
                    type="number"
                    required
                    min={13}
                    max={100}
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 font-semibold"
                  />
                  {formData.age < 13 && (
                    <span className="text-[10px] text-rose-400 block mt-0.5">Kamida 13 yosh bo'lishi shart!</span>
                  )}
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Telefon raqam</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Email manzil</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="talaba@gmail.com"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Login (Username) *</label>
                <input
                  type="text"
                  required
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  placeholder="sardor_dev"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Parol *</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="••••••"
                      className="w-full px-3 py-2 pr-8 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2 top-2.5 text-slate-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Tasdiqlash *</label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      required
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      placeholder="••••••"
                      className="w-full px-3 py-2 pr-8 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-2 top-2.5 text-slate-400 hover:text-white"
                    >
                      {showConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Odamlikni Tasdiqlash (CAPTCHA) */}
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Odamlikni Tasdiqlash (Anti-Bot)
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                    {captchaNum1} + {captchaNum2} = ?
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    required
                    value={captchaAnswer}
                    onChange={(e) => setCaptchaAnswer(e.target.value)}
                    placeholder="Hisob javobini yozing..."
                    className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                  <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={isHumanConfirmed}
                      onChange={(e) => setIsHumanConfirmed(e.target.checked)}
                      className="rounded border-slate-700 text-cyan-600 focus:ring-cyan-500"
                    />
                    <span>Men robot emasman</span>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                disabled={formData.age < 13}
                className="w-full py-3 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-600 hover:to-indigo-700 disabled:opacity-40 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 mt-4"
              >
                <CheckCircle2 className="w-4 h-4" />
                Ro'yxatdan O'tish va Boshlash
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center py-4 space-y-4 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-white">Tabriklaymiz, Ro'yxatdan O'tdingiz!</h3>
            <p className="text-xs text-slate-300">
              Assalomu alaykum, <span className="font-bold text-white">{assignedResult.student.name}</span>! Siz 100 ta darsdan iborat katta dasturlash kursiga qabul qilindingiz.
            </p>
            <button
              onClick={onClose}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition-all"
            >
              Ta'limni Boshlash 🚀
            </button>
          </div>
        )}
      </div>

      {/* Google Sign-in Dialog */}
      {showGoogleModal && (
        <GoogleAuthDialog
          onClose={() => setShowGoogleModal(false)}
          onSuccess={(user) => {
            setShowGoogleModal(false);
            if (onGoogleSuccess) onGoogleSuccess(user);
            onClose();
          }}
        />
      )}
    </div>
  );
};
