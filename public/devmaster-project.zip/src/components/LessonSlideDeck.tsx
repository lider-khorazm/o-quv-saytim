import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Play,
  Copy,
  Check,
  Sparkles,
  Lightbulb,
  Code2,
  BookOpen,
  Keyboard
} from 'lucide-react';
import { LessonSlide, CourseStage } from '../types';

interface LessonSlideDeckProps {
  slides?: LessonSlide[];
  lessonTitle: string;
  stage: CourseStage;
  fallbackSummary: string;
  fallbackCode: string;
  fallbackPoints?: string[];
  onOpenTryIt?: (codeSnippet?: string) => void;
}

export const LessonSlideDeck: React.FC<LessonSlideDeckProps> = ({
  slides: inputSlides,
  lessonTitle,
  stage,
  fallbackSummary,
  fallbackCode,
  fallbackPoints = [],
  onOpenTryIt,
}) => {
  // If slides not explicitly provided, build default 5-slide deck from lesson data
  const defaultDeck: LessonSlide[] = [
    {
      id: 1,
      badge: "1-Slayd: Mavzu Kirishi & Maqsad",
      title: lessonTitle,
      subtitle: `${stage.toUpperCase()} bosqichining asosiy poydevor mavzusi`,
      points: [
        fallbackSummary,
        "Ushbu dars yakunida mavzuning sintaksisi, amaliy qo'llanilishi va ishlab chiqarishdagi standartlarini to'liq o'zlashtirasiz.",
        "Dars davomida namunaviy kodlar bilan tanishib, ularni Try-It studiyasida mustaqil sinab ko'rishingiz mumkin."
      ],
      highlightNote: "Eslatma: Slaydlarni klaviaturadagi chap (←) va o'ng (→) ko'rsatkichlari bilan ham boshqarishingiz mumkin."
    },
    {
      id: 2,
      badge: "2-Slayd: Asosiy Nazariya & Qoidalar",
      title: "Nazariy Asoslar va Brauzer Mexanizmi",
      subtitle: "Brauzer ushbu kodni qanday o'qiydi va qayta ishlaydi?",
      points: fallbackPoints.length > 0 ? fallbackPoints : [
        "Mavzuning brauzer tomonidan qanday parse qilinishini bilish toza kod yozish garovidir.",
        "Semantik qoidalarga qat'iy rioya qilish SEO va foydalanish qulayligini (Accessibility) oshiradi.",
        "Har bir parametr va atributning o'ziga xos vazifasi va cheklovlari mavjud."
      ],
      highlightNote: "Professional dasturchilar shunchaki kod yozmaydi, uning ichki ishlash mexanizmini to'liq tushunadi."
    },
    {
      id: 3,
      badge: "3-Slayd: Namunaviy Kod Tahlili",
      title: "W3Schools Standart Kod Namunasi",
      subtitle: "Amaliy sintaksis va tuzilish bilan tanishing",
      points: [
        "Namunaviy kodni diqqat bilan tahlil qiling.",
        "Ochilish va yopilish teglari, o'zgaruvchilar va xossalar tartibiga e'tibor bering."
      ],
      codeSnippet: fallbackCode,
      highlightNote: "Ushbu kodni 'Try-It da sinash' tugmasi orqali to'g'ridan-to'g'ri tahrirlab natijasini ko'rishingiz mumkin."
    },
    {
      id: 4,
      badge: "4-Slayd: Ishlab Chiqarishdagi Amaliyot",
      title: "Real Loyihalardagi Standartlar",
      subtitle: "Katta dasturlarda qanday qo'llaniladi?",
      points: [
        "Kodni modullarga bo'lib toza saqlash (Clean Code).",
        "Brauzerlararo moslik (Cross-Browser Compatibility) va xatoliklarni oldini olish.",
        "Unumdorlik (Performance) talablariga rioya qilish."
      ],
      highlightNote: "Doimo W3C va ECMAScript zamonaviy standartlariga muvofiq kod yozing."
    },
    {
      id: 5,
      badge: "5-Slayd: Xulosa & Amaliy Topshiriq",
      title: "Bilimlarni Mustahkamlash & Sinov",
      subtitle: "Endi o'zingiz mustaqil kod yozib ko'ring!",
      points: [
        "Barcha slaydlardagi bilimlarni amalda mustahkamlash vaqti keldi.",
        "Try-It Studio yorlig'iga o'ting va berilgan topshiriqni bajaring.",
        "Kodingiz to'g'ri ishlagach, darsni yakunlang va XP mukofotingizni oling!"
      ],
      highlightNote: "Kod yozish — eng yaxshi o'rganish usulidir. Qancha ko'p yozsangiz, shuncha tez o'sasiz!"
    }
  ];

  const slides = (inputSlides && inputSlides.length > 0) ? inputSlides : defaultDeck;
  const [currentIdx, setCurrentIdx] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeSlide = slides[currentIdx] || slides[0];

  const handleNext = () => {
    if (currentIdx < slides.length - 1) {
      setCurrentIdx((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentIdx > 0) {
      setCurrentIdx((prev) => prev - 1);
    }
  };

  // Keyboard navigation: Left, Right, Space
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if focus is on input/textarea
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handlePrev();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIdx, slides.length]);

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement && containerRef.current) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else if (document.exitFullscreen) {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const progressPercent = ((currentIdx + 1) / slides.length) * 100;

  return (
    <div
      ref={containerRef}
      className={`flex flex-col justify-between bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl transition-all ${
        isFullscreen ? 'p-6 sm:p-10 fixed inset-0 z-50 rounded-none' : 'p-4 sm:p-6 min-h-[520px]'
      }`}
    >
      {/* Slide Deck Top Header */}
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-400 font-bold">
              {activeSlide.badge}
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Slide counter */}
            <span className="text-xs font-mono font-bold text-slate-400 bg-slate-900 px-3 py-1 rounded-xl border border-slate-800">
              <strong className="text-white">{currentIdx + 1}</strong> / {slides.length}
            </span>

            {/* Keyboard shortcut hint */}
            <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-slate-500 font-mono">
              <Keyboard className="w-3.5 h-3.5" />
              <span>← / →</span>
            </span>

            {/* Fullscreen Toggle */}
            <button
              onClick={toggleFullscreen}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer border border-slate-800"
              title={isFullscreen ? "To'liq ekrandan chiqish" : "To'liq ekran rejimiga o'tish"}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1 bg-slate-900 mt-2 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-300 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Main Slide Card Body */}
      <div className="my-6 space-y-4">
        {/* Slide Title & Subtitle */}
        <div>
          <h3 className="text-lg sm:text-2xl font-black text-white leading-tight tracking-tight">
            {activeSlide.title}
          </h3>
          {activeSlide.subtitle && (
            <p className="text-xs sm:text-sm text-cyan-300 font-medium mt-1">
              {activeSlide.subtitle}
            </p>
          )}
        </div>

        {/* Slide Bullet Points */}
        {activeSlide.points && activeSlide.points.length > 0 && (
          <div className="space-y-2.5 pt-1">
            {activeSlide.points.map((point, pIdx) => (
              <div
                key={pIdx}
                className="flex items-start gap-3 bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800/80 text-xs sm:text-sm text-slate-200 leading-relaxed shadow-sm hover:border-slate-700 transition-colors"
              >
                <div className="w-5 h-5 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5 border border-cyan-500/20 font-bold text-xs">
                  {pIdx + 1}
                </div>
                <div className="flex-1">
                  <span>{point}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Code Snippet on Slide (if any) */}
        {activeSlide.codeSnippet && (
          <div className="mt-4 rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-inner">
            <div className="p-2.5 px-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs">
              <span className="font-mono text-cyan-400 font-bold flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5" />
                <span>Namunaviy Kod Parchasi</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopyCode(activeSlide.codeSnippet || '')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all text-[11px] flex items-center gap-1 cursor-pointer"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? "Nusxalandi!" : "Nusxa"}</span>
                </button>
                {onOpenTryIt && (
                  <button
                    type="button"
                    onClick={() => onOpenTryIt(activeSlide.codeSnippet)}
                    className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white transition-all text-[11px] font-bold flex items-center gap-1 cursor-pointer active:scale-95 shadow-sm"
                  >
                    <Play className="w-3 h-3" />
                    <span>Try-It da Sinash ▶</span>
                  </button>
                )}
              </div>
            </div>
            <pre className="p-4 text-xs font-mono text-emerald-300 overflow-x-auto leading-relaxed bg-slate-950/80">
              {activeSlide.codeSnippet}
            </pre>
          </div>
        )}

        {/* Highlight Note (Speaker Note) */}
        {activeSlide.highlightNote && (
          <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/30 flex items-start gap-2.5 text-xs text-amber-200">
            <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Spiker maslahati:</strong> {activeSlide.highlightNote}
            </p>
          </div>
        )}
      </div>

      {/* Slide Navigation Bottom Controls */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3 flex-wrap">
        {/* Previous Slide Button */}
        <button
          type="button"
          onClick={handlePrev}
          disabled={currentIdx === 0}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
            currentIdx === 0
              ? 'bg-slate-900 text-slate-600 cursor-not-allowed border border-slate-800'
              : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 active:scale-95'
          }`}
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Oldingi Slayd</span>
        </button>

        {/* Dot indicators */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1">
          {slides.map((_, dotIdx) => (
            <button
              key={dotIdx}
              type="button"
              onClick={() => setCurrentIdx(dotIdx)}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                dotIdx === currentIdx
                  ? 'w-7 bg-cyan-400'
                  : 'w-2 bg-slate-800 hover:bg-slate-700'
              }`}
              title={`${dotIdx + 1}-slaydga o'tish`}
            />
          ))}
        </div>

        {/* Next Slide Button */}
        {currentIdx < slides.length - 1 ? (
          <button
            type="button"
            onClick={handleNext}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-cyan-600/30 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
          >
            <span>Keyingi Slayd</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              if (onOpenTryIt) {
                onOpenTryIt();
              }
            }}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-md shadow-emerald-600/30 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
          >
            <Play className="w-4 h-4" />
            <span>Try-It Studiyasiga O'tish ▶</span>
          </button>
        )}
      </div>
    </div>
  );
};
