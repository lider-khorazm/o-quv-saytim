import React, { useState } from 'react';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  Award,
  Heart,
  RotateCcw,
  Sparkles,
  ArrowRight,
  X,
  AlertTriangle
} from 'lucide-react';
import { Lesson, LessonQuizQuestion, CertificateData } from '../types';
import { recordQuizSubmission } from '../services/storage';

interface LessonQuizModalProps {
  lesson: Lesson;
  studentId: string;
  onClose: () => void;
  onQuizSuccess: (earnedXp: number, newCert?: CertificateData) => void;
}

export const LessonQuizModal: React.FC<LessonQuizModalProps> = ({
  lesson,
  studentId,
  onClose,
  onQuizSuccess,
}) => {
  const questions: LessonQuizQuestion[] = lesson.quiz && lesson.quiz.length > 0
    ? lesson.quiz
    : [
        {
          id: 'q-default-1',
          question: `${lesson.title} mavzusining asosiy mohiyati nima?`,
          options: [
            "Tizimning to'g'ri, xavfsiz va standartlarga mos ishlashini ta'minlash",
            "Faqat brauzer oynasini yopish",
            "Barcha fayllarni format qilish",
            "Foydalanuvchi ma'lumotlarini o'chirish",
          ],
          correctAnswerIndex: 0,
          explanation: "Ushbu tushuncha dasturlash arxitekturasida standart qoidalarga rioya qilgan holda toza kod yozish uchun xizmat qiladi.",
        },
        {
          id: 'q-default-2',
          question: `${lesson.title} bilan ishlashda eng xavfli xato nima?`,
          options: [
            "Standart sintaksis va xavfsizlik qoidalariga e'tibor bermaslik",
            "Kompyuterni qayta yoqish",
            "Izoh (comment) yozish",
            "Kodni konsolda tekshirish",
          ],
          correctAnswerIndex: 0,
          explanation: "Standart sintaksis va xavfsizlik qoidalarini e'tiborsiz qoldirish xatoliklar va sekinlashishga olib keladi.",
        },
        {
          id: 'q-default-3',
          question: `Nima uchun amaliyotda ${lesson.title} qoidalari muhim sanaladi?`,
          options: [
            "Katta miqyosli loyihalarda barqarorlik va yuqori unumdorlik beradi",
            "Kodni faqat bitta odam o'qiy olishi uchun",
            "Brauzer yuklanishini to'xtatish uchun",
            "Hech qanday ahamiyati yo'q",
          ],
          correctAnswerIndex: 0,
          explanation: "Professional loyihalarda barqarorlik va kengaytiriluvchanlik aynan ushbu mezonlar orqali ta'minlanadi.",
        },
      ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [result, setResult] = useState<{
    passed: boolean;
    percentage: number;
    xpGained: number;
    currentHearts: number;
    message: string;
    newCertificate?: CertificateData;
  } | null>(null);

  const currentQ = questions[currentIndex];
  const totalQuestions = questions.length;
  const isLast = currentIndex === totalQuestions - 1;

  const handleSelectOption = (optIndex: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [currentIndex]: optIndex }));
  };

  const handleNext = () => {
    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleSubmit = () => {
    let correctCount = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswerIndex) {
        correctCount++;
      }
    });

    const percentage = Math.round((correctCount / totalQuestions) * 100);
    const subResult = recordQuizSubmission({
      studentId,
      lessonId: lesson.id,
      percentage,
      xpReward: lesson.xpReward || 60,
    });

    setResult(subResult);
    setIsSubmitted(true);

    if (subResult.passed) {
      onQuizSuccess(subResult.xpGained, subResult.newCertificate);
    }
  };

  const handleRetry = () => {
    setSelectedAnswers({});
    setCurrentIndex(0);
    setIsSubmitted(false);
    setResult(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Dars Sinov Testi</h3>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                  +{lesson.xpReward || 60} XP
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-xs">{lesson.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-800 h-1.5">
          <div
            className="bg-gradient-to-r from-amber-500 to-indigo-500 h-1.5 transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
          />
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {!isSubmitted ? (
            <>
              {/* Question count */}
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>
                  Savol <strong className="text-white">{currentIndex + 1}</strong> / {totalQuestions}
                </span>
                <span className="text-amber-400 font-medium">O'tish bali: 70%</span>
              </div>

              {/* Question Text */}
              <div className="space-y-3">
                <h4 className="text-base font-bold text-slate-100 leading-snug">
                  {currentQ.question}
                </h4>

                {currentQ.codeSnippet && (
                  <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-300 overflow-x-auto">
                    {currentQ.codeSnippet}
                  </pre>
                )}
              </div>

              {/* Options */}
              <div className="space-y-2.5">
                {currentQ.options.map((opt, optIdx) => {
                  const isSelected = selectedAnswers[currentIndex] === optIdx;
                  return (
                    <button
                      key={optIdx}
                      onClick={() => handleSelectOption(optIdx)}
                      className={`w-full p-3.5 rounded-xl border text-left text-xs sm:text-sm font-medium transition-all flex items-center justify-between gap-3 ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-500 text-white shadow-md'
                          : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800/60 hover:text-white'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <span
                          className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold ${
                            isSelected
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        {opt}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Navigation buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handlePrev}
                  disabled={currentIndex === 0}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white disabled:opacity-30 transition-colors"
                >
                  ← Oldingi
                </button>

                {isLast ? (
                  <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={Object.keys(selectedAnswers).length < totalQuestions}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 disabled:opacity-40 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Testni Yakunlash
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleNext}
                    disabled={selectedAnswers[currentIndex] === undefined}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md"
                  >
                    Keyingisi
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </>
          ) : (
            /* Result Screen */
            <div className="text-center space-y-6 py-4 animate-fadeIn">
              <div className="relative inline-block">
                <div
                  className={`w-20 h-20 mx-auto rounded-3xl flex items-center justify-center shadow-2xl ${
                    result?.passed
                      ? 'bg-emerald-500/20 text-emerald-400 border-2 border-emerald-500/40'
                      : 'bg-rose-500/20 text-rose-400 border-2 border-rose-500/40'
                  }`}
                >
                  {result?.passed ? (
                    <Award className="w-10 h-10 animate-bounce" />
                  ) : (
                    <AlertTriangle className="w-10 h-10 animate-pulse" />
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl font-black text-white">
                  {result?.passed ? "Testdan O'tdingiz! 🎉" : "Testdan Yiqildingiz! ⚠️"}
                </h3>
                <p className="text-sm font-semibold text-slate-300">
                  Natija: <span className={result?.passed ? 'text-emerald-400' : 'text-rose-400'}>{result?.percentage}%</span> (kamida 70% kerak)
                </p>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  {result?.message}
                </p>
              </div>

              {result?.passed ? (
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center gap-4 text-emerald-300 text-xs">
                  <span className="font-bold text-sm">+{result.xpGained} XP Profilingizga Qo'shildi!</span>
                  <span>🪙 +15 Tangalar</span>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center gap-3 text-rose-300 text-xs">
                  <Heart className="w-4 h-4 text-rose-500" />
                  <span>Siz bitta jon yo'qotdingiz. Darsni qayta o'qib, yana topshiring!</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-center gap-3 pt-2">
                {!result?.passed && (
                  <button
                    onClick={handleRetry}
                    className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Qaytadan Sinash
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md transition-all"
                >
                  {result?.passed ? "Davom Etish 🚀" : "Darsga Qaytish 📖"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
