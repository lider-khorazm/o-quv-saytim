import React, { useState } from 'react';
import { Bot, Send, Sparkles, AlertCircle, RefreshCw, X, ShieldAlert } from 'lucide-react';
import { askStudentAssistant } from '../services/groqService';

interface StudentAiAssistantProps {
  currentLessonTitle: string;
  currentLessonStage: string;
  currentCodeSnippet?: string;
  onClose?: () => void;
}

export const StudentAiAssistant: React.FC<StudentAiAssistantProps> = ({
  currentLessonTitle,
  currentLessonStage,
  currentCodeSnippet,
  onClose,
}) => {
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; text: string; time: string }[]>([
    {
      role: 'assistant',
      text: `Salom! Men sizning shaxsiy **"Yordamchi"** AI repetitoringizman. 🤖\n\nHozir o'rganayotgan darsingiz: **"${currentLessonTitle}"**.\nUshbu mavzu bo'yicha tushunmagan joyingiz, sintaksis yoki xatolaringiz bo'lsa, bemalol so'rang! *(Eslatma: Men qat'iy ravishda faqat shu dars bo'yicha javob beraman).*`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || loading) return;

    const userText = input.trim();
    const userTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setMessages((prev) => [...prev, { role: 'user', text: userText, time: userTime }]);
    setInput('');
    setLoading(true);

    try {
      const res = await askStudentAssistant({
        currentLessonTitle,
        currentLessonStage,
        userPrompt: userText,
        codeSnippet: currentCodeSnippet,
        chatHistory: messages,
      });

      const aiTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setMessages((prev) => [...prev, { role: 'assistant', text: res.text, time: aiTime }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: "Tarmoq xatosi yuz berdi. Iltimos, savolingizni qaytadan yuboring.",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    "Ushbu kod nima ish bajaradi?",
    "Eng ko'p qilinadigan xatoni tushuntir",
    "Sintaksisni sodda misolda ko'rsat",
  ];

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-slate-900 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-sm text-white">Yordamchi AI</h4>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Mavzuga Biriktirilgan
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate max-w-[240px] sm:max-w-xs">
              Mavzu: <span className="text-slate-200">{currentLessonTitle}</span>
            </p>
          </div>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Guardrail notice */}
      <div className="px-4 py-2 bg-indigo-950/40 border-b border-indigo-500/20 flex items-center gap-2 text-[11px] text-indigo-300">
        <ShieldAlert className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
        <span>Faqat ushbu dars va dasturlash bo'yicha tushuntirish beradi.</span>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 min-h-[260px] max-h-[380px]">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[88%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                m.role === 'user'
                  ? 'bg-indigo-600 text-white rounded-br-none shadow-md'
                  : 'bg-slate-800/90 text-slate-200 border border-slate-700/60 rounded-bl-none shadow-sm'
              }`}
            >
              <div className="whitespace-pre-wrap">{m.text}</div>
            </div>
            <span className="text-[10px] text-slate-400 mt-1 px-1">{m.time}</span>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-xs text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 p-3 rounded-xl w-fit">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>Yordamchi dars bo'yicha tahlil qilmoqda...</span>
          </div>
        )}
      </div>

      {/* Quick Prompts */}
      <div className="px-3 py-2 bg-slate-950/60 border-t border-slate-800 flex items-center gap-1.5 overflow-x-auto text-[11px] scrollbar-none">
        {quickPrompts.map((qp, i) => (
          <button
            key={i}
            onClick={() => {
              setInput(qp);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 whitespace-nowrap transition-colors"
          >
            {qp}
          </button>
        ))}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ushbu dars bo'yicha savolingizni yozing..."
          className="flex-1 px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-medium text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md shrink-0"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">So'rash</span>
        </button>
      </form>
    </div>
  );
};
