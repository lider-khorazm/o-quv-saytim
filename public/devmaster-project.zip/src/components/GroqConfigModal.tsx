import React, { useState } from 'react';
import { Key, Sparkles, CheckCircle2, ShieldAlert, Cpu, ExternalLink, X } from 'lucide-react';
import { getGroqApiKey, setGroqApiKey, clearGroqApiKey, hasGroqApiKey } from '../services/groqService';

interface GroqConfigModalProps {
  onClose: () => void;
  onSaved?: () => void;
}

export const GroqConfigModal: React.FC<GroqConfigModalProps> = ({ onClose, onSaved }) => {
  const [apiKey, setApiKey] = useState(getGroqApiKey());
  const [isSaved, setIsSaved] = useState(false);
  const isConnected = hasGroqApiKey();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setGroqApiKey(apiKey);
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      if (onSaved) onSaved();
      onClose();
    }, 1200);
  };

  const handleClear = () => {
    clearGroqApiKey();
    setApiKey('');
    if (onSaved) onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-gradient-to-r from-orange-500/10 via-purple-500/10 to-indigo-500/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center border border-orange-500/30">
              <Cpu className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Groq AI Ekotizimi Sozlamalari
                <span className="text-xs px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-400 font-normal border border-orange-500/30">
                  Llama 3.3 70B
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                4 ta sun'iy intellekt modeli uchun yuqori tezlikdagi server kaliti
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Status Banner */}
          <div className={`p-4 rounded-xl border flex items-start gap-3 ${
            isConnected
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
          }`}>
            {isConnected ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            )}
            <div className="text-xs leading-relaxed">
              <p className="font-semibold text-sm mb-0.5">
                {isConnected ? 'Groq Llama 3.3 70B Faol Holatda' : 'Smart Offline AI Engine Rejimi'}
              </p>
              <p className="text-slate-300">
                {isConnected
                  ? "Siz kiritgan Groq API kaliti faol. Barcha 4 ta AI agentlari to'g'ridan-to'g'ri Llama 3.3 70B orqali javob bermoqda."
                  : "Kalit kiritilmagan taqdirda ham, platformadagi 4 ta AI agenti o'rnatilgan aqlli bilimlar bazasiga tayangan holda benuqson ishlaydi. Eng yuqori darajadagi Llama 3.3 modeliga ulanish uchun quyiga Groq kalitini kiritishingiz mumkin."}
              </p>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-orange-400" />
                  Groq API Kaliti (gsk_...)
                </span>
                <a
                  href="https://console.groq.com/keys"
                  target="_blank"
                  rel="noreferrer"
                  className="text-orange-400 hover:text-orange-300 flex items-center gap-1 hover:underline text-[11px]"
                >
                  Bepul kalit olish (console.groq.com)
                  <ExternalLink className="w-3 h-3" />
                </a>
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="gsk_..."
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 transition-all font-mono"
              />
              <p className="text-[11px] text-slate-400 mt-1.5">
                Kalitingiz faqat brauzeringiz xotirasida (localStorage) saqlanadi va hech kimga yuborilmaydi.
              </p>
            </div>

            {/* AI Agents breakdown */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
              <p className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Ushbu kalit orqali ishlovchi 4 ta sun'iy intellekt agenti:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                  <span className="font-bold text-indigo-400">1. Yordamchi</span>: O'quvchi dars repetitori (qat'iy dars mavzusi bo'yicha).
                </div>
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                  <span className="font-bold text-emerald-400">2. Ustoz Temur</span>: Bosh AI Murabbiy (kod tekshirish, pedagogik maslahat).
                </div>
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                  <span className="font-bold text-amber-400">3. Admin Jasur</span>: Monitoring va Xavfsizlik bo'yicha AI Co-Admin.
                </div>
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                  <span className="font-bold text-purple-400">4. Admin Nigora</span>: Akademik hisobotlar va XP tahlili AI Co-Admini.
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-between pt-2">
              {apiKey ? (
                <button
                  type="button"
                  onClick={handleClear}
                  className="px-3 py-2 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg transition-colors"
                >
                  Kalitni o'chirish
                </button>
              ) : <div />}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 text-xs font-semibold rounded-xl text-white transition-all shadow-md flex items-center gap-1.5 ${
                    isSaved
                      ? 'bg-emerald-600'
                      : 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600'
                  }`}
                >
                  {isSaved ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      Saqlandi!
                    </>
                  ) : (
                    <>
                      <Key className="w-4 h-4" />
                      Kalitni Saqlash
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
