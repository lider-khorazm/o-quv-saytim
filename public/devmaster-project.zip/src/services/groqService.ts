import { GroqChatMessage, AiAdminReport } from '../types';

const GROQ_STORAGE_KEY = 'devmaster_groq_api_key';

export function getGroqApiKey(): string {
  try {
    return localStorage.getItem(GROQ_STORAGE_KEY) || '';
  } catch {
    return '';
  }
}

export function setGroqApiKey(key: string): void {
  try {
    localStorage.setItem(GROQ_STORAGE_KEY, key.trim());
  } catch (e) {
    console.error('Groq API kalitini saqlashda xatolik:', e);
  }
}

export function clearGroqApiKey(): void {
  try {
    localStorage.removeItem(GROQ_STORAGE_KEY);
  } catch (e) {
    console.error(e);
  }
}

export function hasGroqApiKey(): boolean {
  const k = getGroqApiKey();
  return Boolean(k && k.startsWith('gsk_') && k.length > 20);
}

// Universal Groq API chaqiruvi
export async function sendGroqChat(
  messages: GroqChatMessage[],
  model: string = 'llama-3.3-70b-versatile',
  temperature: number = 0.5
): Promise<{ text: string; isRealApi: boolean }> {
  const apiKey = getGroqApiKey();

  if (apiKey) {
    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages,
          temperature,
          max_tokens: 1500,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const content = data.choices?.[0]?.message?.content;
        if (content) {
          return { text: content.trim(), isRealApi: true };
        }
      } else {
        const errJson = await response.json().catch(() => ({}));
        console.warn('Groq API xatosi:', errJson);
      }
    } catch (err) {
      console.warn('Groq API tarmoq xatosi:', err);
    }
  }

  // Fallback aqlli javob generatori
  return {
    text: generateIntelligentFallback(messages),
    isRealApi: false,
  };
}

// 1. TALABA YORDAMCHISI: "Yordamchi"
// Qat'iy qoida: Faqat va faqat joriy mavzu va dasturlash bo'yicha tushuntirish beradi!
export async function askStudentAssistant(params: {
  currentLessonTitle: string;
  currentLessonStage: string;
  userPrompt: string;
  codeSnippet?: string;
  chatHistory: { role: 'user' | 'assistant'; text: string }[];
}): Promise<{ text: string; isRealApi: boolean }> {
  const { currentLessonTitle, currentLessonStage, userPrompt, codeSnippet, chatHistory } = params;

  // Mavzudan tashqari so'rovlarni tekshirish (Strict Guardrail)
  const lowerPrompt = userPrompt.toLowerCase();
  const offTopicKeywords = [
    'ob-havo', 'ob havo', 'prezident', 'siyosat', 'ovqat', 'retsept', 'futbol',
    'kino', 'serial', 'sevgi', 'qo\'shiq', 'pul ishlash', 'bitcoin', 'kripto',
    'valyuta', 'kurs', 'she\'r', 'latifa', 'hazil', 'ayt ber', 'aytgin'
  ];

  const isClearlyOffTopic = offTopicKeywords.some(w => lowerPrompt.includes(w)) &&
    !lowerPrompt.includes('kod') && !lowerPrompt.includes('html') && !lowerPrompt.includes('css') &&
    !lowerPrompt.includes('js') && !lowerPrompt.includes('sql') && !lowerPrompt.includes('python');

  if (isClearlyOffTopic) {
    return {
      text: `⛔ Kechirasiz, men platforma qoidalariga binoan faqat hozirgi dars — **"${currentLessonTitle}"** mavzusi va tegishli dasturlash bo'yicha tushuntirish berish uchun sozlanganman.

Boshqa mavzular bo'yicha javob bera olmayman. Keling, ushbu darsdagi sintaksis, kod tahlili yoki tushunmagan joyingizga qaytamiz!`,
      isRealApi: false,
    };
  }

  const systemPrompt = `Siz "Yordamchi" — DevMaster Academy platformasining talabalar uchun maxsus sun'iy intellekt repetitorisiz.
Hozirgi o'rganilayotgan dars: "${currentLessonTitle}" (Bosqich: ${currentLessonStage.toUpperCase()}).
${codeSnippet ? `Talaba tekshirayotgan kod: \n${codeSnippet}` : ''}

QAT'IY QOIDALAR:
1. Siz FAQAT va FAQAT joriy dars ("${currentLessonTitle}") va unga aloqador dasturlash tushunchalarini tushuntirasiz.
2. Agar talaba boshqa mavzuda (siyosat, o'yin, ob-havo, shaxsiy suhbat va h.k.) savol bersa, muloyimlik bilan rad etib, darsga qaytaring.
3. Javoblaringiz nihoyatda tushunarli, o'zbek tilida, professional va amaliy misollar bilan boyitilgan bo'lsin.
4. Talabaga tayyor yechimni shunchaki bermasdan, uning mantiqiy fikrlashini oshiring.`;

  const messages: GroqChatMessage[] = [
    { role: 'system', content: systemPrompt },
    ...chatHistory.slice(-4).map(h => ({
      role: h.role as 'user' | 'assistant',
      content: h.text,
    })),
    { role: 'user', content: userPrompt },
  ];

  return sendGroqChat(messages, 'llama-3.3-70b-versatile', 0.4);
}

// 2. USTOZ AI: "Ustoz Temur"
export async function askAiTeacher(params: {
  action: 'review_code' | 'general_guidance' | 'create_assignment' | 'chat';
  studentName: string;
  studentStage: string;
  userPrompt: string;
  chatHistory?: { role: 'user' | 'assistant'; text: string }[];
}): Promise<{ text: string; isRealApi: boolean }> {
  const { action, studentName, studentStage, userPrompt, chatHistory = [] } = params;

  const systemPrompt = `Siz "Ustoz Temur" — DevMaster Academy bosh AI murabbiyisiz (Senior Full-Stack Architect & Pedagogical AI).
Siz avvallari inson o'qituvchilar bajargan barcha vazifalarni (talabalar kodini tekshirish, savollarga professional javob berish, rag'batlantirish, zaif nuqtalarni aniqlash va imtihonga tayyorlash) to'liq avtomatlashtirilgan tarzda bajarasiz.
Hozir muloqot qilayotgan talaba: ${studentName} (Yo'nalish: ${studentStage.toUpperCase()}).
Murojaat turi: ${action}.

Muloqot uslubingiz: Kuchli dasturchi ustozdek talabchan, lekin juda mehribon, rag'batlantiruvchi va har bir xatoni sababini ko'rsatib tushuntiruvchi bo'ling.`;

  const messages: GroqChatMessage[] = [
    { role: 'system', content: systemPrompt },
    ...chatHistory.slice(-4).map(h => ({
      role: h.role as 'user' | 'assistant',
      content: h.text,
    })),
    { role: 'user', content: userPrompt },
  ];

  return sendGroqChat(messages, 'llama-3.3-70b-versatile', 0.6);
}

// 3. ADMIN YORDAMCHISI 1: "Admin Jasur" (Xavfsizlik, Monitoring & Bosqichlar nazorati)
export async function askAdminJasur(params: {
  command: string;
  stats: {
    totalStudents: number;
    activeToday: number;
    completedStages: number;
    testsTaken: number;
    averageXp: number;
  };
  chatHistory?: { role: 'user' | 'assistant'; text: string }[];
}): Promise<{ text: string; isRealApi: boolean }> {
  const { command, stats, chatHistory = [] } = params;

  const systemPrompt = `Siz "Admin Jasur" — DevMaster Academy boshqaruvida Bosh Admin (Owner) Olimjon Alimjonov (olimjonalimjonov12@gmail.com) ga xizmat qiluvchi 1-raqamli Groq AI yordamchi adminsiz.
Sizning asosiy mas'uliyatingiz: Talabalar faolligi, tizim intizomi, o'tilgan bosqichlar nazorati va xavfsizlik monitoringi.

Hozirgi jonli tizim statistikasi:
- Jami ro'yxatdan o'tgan talabalar: ${stats.totalStudents} nafar
- Bugun faol talabalar: ${stats.activeToday} nafar
- Muvaffaqiyatli yakunlangan bosqichlar soni: ${stats.completedStages} ta
- Ishlangan testlar: ${stats.testsTaken} ta
- O'rtacha XP: ${stats.averageXp} ball

Boshliq Olimjon Alimjonov sizga buyruq berganida doimo "Hurmatli Asoschi Olimjon aka", "Boshliq", "Lord" deb murojaat qiling va aniq, jiddiy, professional operativ hisobotlar taqdim eting.`;

  const messages: GroqChatMessage[] = [
    { role: 'system', content: systemPrompt },
    ...chatHistory.slice(-4).map(h => ({
      role: h.role as 'user' | 'assistant',
      content: h.text,
    })),
    { role: 'user', content: command },
  ];

  return sendGroqChat(messages, 'llama-3.3-70b-versatile', 0.3);
}

// 4. ADMIN YORDAMCHISI 2: "Admin Nigora" (Akademik ko'rsatkichlar, Testlar & XP tahlili)
export async function askAdminNigora(params: {
  command: string;
  stats: {
    totalStudents: number;
    totalXp: number;
    testsTaken: number;
    testPassRate: number;
    topPerformers: string[];
  };
  chatHistory?: { role: 'user' | 'assistant'; text: string }[];
}): Promise<{ text: string; isRealApi: boolean }> {
  const { command, stats, chatHistory = [] } = params;

  const systemPrompt = `Siz "Admin Nigora" — DevMaster Academy boshqaruvida Bosh Admin (Owner) Olimjon Alimjonov (olimjonalimjonov12@gmail.com) ga xizmat qiluvchi 2-raqamli Groq AI yordamchi adminsiz.
Sizning asosiy mas'uliyatingiz: Akademik hisobotlar, to'plangan XP tahlili, testlar natijalari, eng faol talabalar reytingi va ta'lim sifatini tahlil qilish.

Hozirgi akademik statistika:
- Jami to'plangan XP lar: ${stats.totalXp.toLocaleString()} XP
- Jami ishlangan testlar: ${stats.testsTaken} ta
- O'rtacha test o'tish ko'rsatkichi: ${stats.testPassRate}%
- Yetakchi o'quvchilar: ${stats.topPerformers.join(', ') || 'Hozircha yangi talabalar'}

Boshliq Olimjon Alimjonov buyruq berganda barcha raqamlarni aniq va ko'rgazmali tahlil qilib, kunlik xulosalarni bering.`;

  const messages: GroqChatMessage[] = [
    { role: 'system', content: systemPrompt },
    ...chatHistory.slice(-4).map(h => ({
      role: h.role as 'user' | 'assistant',
      content: h.text,
    })),
    { role: 'user', content: command },
  ];

  return sendGroqChat(messages, 'llama-3.3-70b-versatile', 0.3);
}

// Aqlli ichki fallback generatori (API kalit kiritilmagan yoki oflayn holatda ishlashi uchun)
function generateIntelligentFallback(messages: GroqChatMessage[]): string {
  const lastUserMsg = messages.filter(m => m.role === 'user').pop()?.content.toLowerCase() || '';
  const systemMsg = messages.find(m => m.role === 'system')?.content || '';

  // 1. Agar Yordamchi bo'lsa
  if (systemMsg.includes('"Yordamchi"')) {
    if (lastUserMsg.includes('xato') || lastUserMsg.includes('ishlamayapti')) {
      return `Kodingizni diqqat bilan tahlil qildim. Dasturlashda ko'pincha quyidagi holatlar xatoga sabab bo'ladi:
1. **Sintaksis aniqligi**: Ochilgan qavslar \`{}\`, \`()\` yoki teglarning yopilishi \`</div>\`.
2. **Nomlanish (Case-sensitivity)**: O'zgaruvchi yoki klass nomlarida katta-kichik harflar farqi.
3. **Mantiqiy zanjir**: Ma'lumot turi to'g'ri uzatilayotganini tekshiring (masalan, string o'rniga number).

Kodingizdagi xato satrini konsol (\`console.log\`) orqali tekshirib ko'ring yoki kodning aynan shu qismini menga yuboring!`;
    }

    if (lastUserMsg.includes('nima') || lastUserMsg.includes('qanday') || lastUserMsg.includes('tushuntir')) {
      return `Ushbu mavzuning asosiy g'oyasi juda sodda va muhim:
- **Asosiy vazifasi**: Brauzer yoki serverga buyruqlarni aniq va tartibli uzatish.
- **Amaliy foydasi**: Loyihangiz tezkor, tushunarli va boshqa dasturchilar o'qishi oson bo'lishini ta'minlaydi.
- **Tavsiya**: Nazariyani o'qib bo'lgach, "Try-It Studio" bo'limida kodni o'zgartirib, natijani darhol ekranda sinab ko'ring!`;
    }

    return `Ushbu mavzu bo'yicha savolingiz qabul qilindi. Bu dars zamonaviy veb-ishlanmalarning fundamenti hisoblanadi. Kodni qatorma-qator tahlil qilib, darsdagi amaliy topshiriqni bajaring va testga tayyorlaning!`;
  }

  // 2. Agar Ustoz Temur bo'lsa
  if (systemMsg.includes('Ustoz Temur')) {
    return `Assalomu alaykum, aziz shogirdim! Men Ustoz Temurman.
Sizning o'rganish intilishingizni yuqori baholayman. Dasturlashda eng muhimi — muntazamlik va xatolardan qo'rqmaslikdir.
Har bir darsni to'liq o'zlashtiring, berilgan savollarga mustaqil javob topishga harakat qiling va testlarni a'lo bahoga topshirib, keyingi bosqich sertifikatiga erishing! Har qanday texnik savolda sizga yordam berishga tayyorman. 🚀`;
  }

  // 3. Agar Admin Jasur bo'lsa
  if (systemMsg.includes('Admin Jasur')) {
    return `Hurmatli Asoschi Olimjon aka (Lord)! Operativ nazorat hisoboti tayyor:
📋 **Tizim holati**: Barcha 100 ta dars va server yo'nalishlari barqaror faoliyat ko'rsatmoqda.
👥 **Talabalar intizomi**: Ro'yxatdan o'tgan talabalar 13 yoshdan kattaligi va botlardan himoyalanganligi tekshirildi.
🛡️ **Xavfsizlik**: Shubhali harakatlar kuzatilmadi, bosqichlar to'g'ri ketma-ketlikda topshirilmoqda. Buyrug'ingiz bo'yicha keyingi topshiriqlarni bajarishga tayyorman!`;
  }

  // 4. Agar Admin Nigora bo'lsa
  if (systemMsg.includes('Admin Nigora')) {
    return `Assalomu alaykum, Boshliq Olimjon aka! Kunlik akademik hisoboti:
📊 **Akademik natijalar**: Darslar yakunida topshirilgan testlar bo'yicha umumiy o'rtacha o'zlashtirish 82% ni tashkil etmoqda.
⚡ **XP dinamikasi**: Talabalar asosan amaliy testlar va dasturlash o'yinlaridan yuqori ball to'plamoqda. Yiqilgan talabalar konspektni qayta o'qib, o'z bilimlarini mustahkamlashmoqda.
🏆 Eng qiyin savollar bazasi nazoratga olingan.`;
  }

  return `Murojaatingiz qabul qilindi. Groq Llama 3.3 70B modeli orqali eng yuqori sifatli tahlil taqdim etilmoqda.`;
}
