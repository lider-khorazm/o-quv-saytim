// Markaziy ma'lumot ombori (hamma kompyuterlar uchun bitta joy).
// DATABASE_URL (yoki SQL_HOST) bo'lsa — Postgres; bo'lmasa — data/store.json fayli.
import fs from 'fs';
import path from 'path';
import { createPool, hasPostgresConfig } from './src/db/index.ts';

// Brauzerlar o'rtasida bo'lishiladigan kalitlar (src/services/storage.ts bilan bir xil bo'lishi shart).
// AUTH_USER ATAYLAB yo'q: kim tizimga kirgani har bir brauzerda alohida qoladi.
export const SHARED_KEYS = [
  'devmaster_teachers_v3',
  'devmaster_students_v2',
  'devmaster_generated_tests_v2',
  'devmaster_test_submissions_v2',
  'devmaster_expel_requests_v2',
  'devmaster_notifications_v2',
  'devmaster_group_messages_v2',
];

export interface Row {
  value: unknown;
  version: number;
}
export type PutResult = { ok: true; version: number } | { ok: false; current: Row | null };

interface Backend {
  name: 'postgres' | 'file';
  init(): Promise<void>;
  all(): Promise<Record<string, Row>>;
  put(key: string, value: unknown, baseVersion: number): Promise<PutResult>;
}

// ---------------- Postgres ----------------
function postgresBackend(): Backend {
  const pool = createPool();
  const getRow = async (key: string): Promise<Row | null> => {
    const r = await pool.query('SELECT value, version FROM kv_store WHERE key = $1', [key]);
    return r.rows[0] ? { value: r.rows[0].value, version: r.rows[0].version } : null;
  };
  return {
    name: 'postgres',
    async init() {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS kv_store (
          key text PRIMARY KEY,
          value jsonb NOT NULL,
          version integer NOT NULL DEFAULT 1,
          updated_at timestamptz NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS users (
          id serial PRIMARY KEY, uid text NOT NULL UNIQUE, email text NOT NULL,
          name text, role text DEFAULT 'student', created_at timestamp DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS staff_members (
          id serial PRIMARY KEY, name text NOT NULL, role text NOT NULL,
          login text NOT NULL UNIQUE, password text NOT NULL,
          assigned_by text DEFAULT 'legend_o1', status text DEFAULT 'active',
          created_at timestamp DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS staff_messages (
          id serial PRIMARY KEY, sender_name text NOT NULL, sender_role text NOT NULL,
          sender_login text NOT NULL, text text NOT NULL, is_urgent text DEFAULT 'false',
          created_at timestamp DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS claimed_gifts (
          id serial PRIMARY KEY, student_name text NOT NULL,
          student_email text NOT NULL UNIQUE, gift_code text NOT NULL,
          gift_title text NOT NULL, claimed_at timestamp DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS student_projects (
          id serial PRIMARY KEY, title text NOT NULL, student_name text NOT NULL,
          student_email text NOT NULL, student_city text, category text NOT NULL,
          description text, html_code text NOT NULL, status text DEFAULT 'pending',
          likes integer DEFAULT 0, created_at timestamp DEFAULT now()
        );
      `);
    },
    async all() {
      const r = await pool.query('SELECT key, value, version FROM kv_store');
      const out: Record<string, Row> = {};
      for (const row of r.rows) out[row.key] = { value: row.value, version: row.version };
      return out;
    },
    async put(key, value, baseVersion) {
      const json = JSON.stringify(value);
      if (baseVersion === 0) {
        const ins = await pool.query(
          'INSERT INTO kv_store (key, value, version) VALUES ($1, $2::jsonb, 1) ON CONFLICT (key) DO NOTHING RETURNING version',
          [key, json]
        );
        if (ins.rows[0]) return { ok: true, version: ins.rows[0].version };
        return { ok: false, current: await getRow(key) };
      }
      const upd = await pool.query(
        'UPDATE kv_store SET value = $2::jsonb, version = version + 1, updated_at = now() WHERE key = $1 AND version = $3 RETURNING version',
        [key, json, baseVersion]
      );
      if (upd.rows[0]) return { ok: true, version: upd.rows[0].version };
      return { ok: false, current: await getRow(key) };
    },
  };
}

// ---------------- Fayl (zaxira / lokal) ----------------
function fileBackend(): Backend {
  const dir = path.resolve(process.cwd(), 'data');
  const file = path.join(dir, 'store.json');
  let data: Record<string, Row> = {};
  const save = () => {
    fs.mkdirSync(dir, { recursive: true });
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data));
    fs.renameSync(tmp, file);
  };
  return {
    name: 'file',
    async init() {
      try {
        data = JSON.parse(fs.readFileSync(file, 'utf8'));
      } catch {
        data = {};
      }
    },
    async all() {
      return data;
    },
    async put(key, value, baseVersion) {
      const cur = data[key];
      if ((cur?.version ?? 0) !== baseVersion) return { ok: false, current: cur ?? null };
      const version = (cur?.version ?? 0) + 1;
      data[key] = { value, version };
      save();
      return { ok: true, version };
    },
  };
}

export let store: Backend = fileBackend();

export async function initStore(): Promise<void> {
  if (hasPostgresConfig) {
    try {
      const pg = postgresBackend();
      await pg.init();
      store = pg;
      console.log('Ma\'lumotlar ombori: Postgres ulandi');
      return;
    } catch (err) {
      console.error('XATO: Postgres ga ulanib bo\'lmadi, vaqtincha fayl ombori ishlatiladi:', err);
    }
  } else {
    console.warn('DIQQAT: DATABASE_URL berilmagan — ma\'lumotlar data/store.json faylida saqlanadi (Render bepul tarifida bu o\'chib ketadi).');
  }
  store = fileBackend();
  await store.init();
}
