import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema.ts';

declare global {
  var _postgresPool: Pool | undefined;
}

/** Postgres ulanishi sozlanganmi? (DATABASE_URL yoki SQL_HOST) */
export const hasPostgresConfig = Boolean(process.env.DATABASE_URL || process.env.SQL_HOST);

export const createPool = () => {
  if (!global._postgresPool) {
    const url = process.env.DATABASE_URL;
    // Supabase / Neon / Render tashqi ulanishlari SSL talab qiladi.
    // Kerak bo'lmasa: DATABASE_SSL=false
    const ssl = process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false };

    global._postgresPool = url
      ? new Pool({ connectionString: url, ssl, max: 10, connectionTimeoutMillis: 15000 })
      : new Pool({
          host: process.env.SQL_HOST,
          user: process.env.SQL_USER,
          password: process.env.SQL_PASSWORD,
          database: process.env.SQL_DB_NAME,
          max: 10,
          connectionTimeoutMillis: 15000,
        });

    global._postgresPool.on('error', (err) => {
      console.error('Unexpected error on idle SQL pool client:', err);
    });
  }
  return global._postgresPool;
};

const pool = createPool();
export const db = drizzle(pool, { schema });
