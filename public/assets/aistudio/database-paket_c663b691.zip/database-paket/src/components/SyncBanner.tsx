import { useEffect, useState } from 'react';
import { getSyncStatus, STATUS_EVENT, type SyncStatus } from '../services/remoteStore';

/** Server bilan aloqa uzilsa ogohlantiradi — aks holda ma'lumot yana faqat shu kompyuterda qolib ketadi. */
export function SyncBanner() {
  const [status, setStatus] = useState<SyncStatus>(getSyncStatus());

  useEffect(() => {
    const onChange = (e: Event) => setStatus((e as CustomEvent<SyncStatus>).detail);
    window.addEventListener(STATUS_EVENT, onChange);
    return () => window.removeEventListener(STATUS_EVENT, onChange);
  }, []);

  if (status !== 'offline') return null;
  return (
    <div
      role="alert"
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 9999,
        background: '#b91c1c',
        color: '#fff',
        padding: '8px 12px',
        fontSize: 14,
        textAlign: 'center',
      }}
    >
      Server bilan aloqa yo'q — o'zgarishlar hozircha faqat shu kompyuterda. Aloqa qaytgach avtomatik yuboriladi.
    </div>
  );
}
