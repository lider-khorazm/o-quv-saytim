import {
  Student,
  Teacher,
  GeneratedTest,
  TestSubmissionResult,
  ExpelRequest,
  TeacherNotification,
  GroupChatMessage,
  CourseStage,
  AuthUser,
  CertificateData
} from '../types';
import {
  INITIAL_TEACHERS,
  INITIAL_STUDENTS,
  QUESTION_BANK,
  OWNER_CREDENTIALS,
  OWNER_PROFILE,
  LESSONS
} from '../data/mockData';

import { initRemote, isShared, hasShared, getShared, setShared } from './remoteStore';

const STORAGE_KEYS = {
  TEACHERS: 'devmaster_teachers_v3',
  STUDENTS: 'devmaster_students_v2',
  GENERATED_TESTS: 'devmaster_generated_tests_v2',
  TEST_SUBMISSIONS: 'devmaster_test_submissions_v2',
  EXPEL_REQUESTS: 'devmaster_expel_requests_v2',
  NOTIFICATIONS: 'devmaster_notifications_v2',
  GROUP_MESSAGES: 'devmaster_group_messages_v2',
  AUTH_USER: 'devmaster_current_auth_user_v2',
};

// Bu kalitlar BARCHA kompyuterlar uchun umumiy (serverda saqlanadi).
// AUTH_USER ro'yxatda yo'q: kim tizimga kirgani har bir brauzerda alohida.
export const SHARED_STORAGE_KEYS = [
  STORAGE_KEYS.TEACHERS,
  STORAGE_KEYS.STUDENTS,
  STORAGE_KEYS.GENERATED_TESTS,
  STORAGE_KEYS.TEST_SUBMISSIONS,
  STORAGE_KEYS.EXPEL_REQUESTS,
  STORAGE_KEYS.NOTIFICATIONS,
  STORAGE_KEYS.GROUP_MESSAGES,
];

/** Ilova ochilganda bir marta chaqiriladi: markaziy ombordan ma'lumotni yuklaydi. */
export async function initRemoteStorage(): Promise<void> {
  await initRemote(SHARED_STORAGE_KEYS);
}

function hasStored(key: string): boolean {
  return isShared(key) ? hasShared(key) : localStorage.getItem(key) !== null;
}

function loadFromStorage<T>(key: string, fallback: T): T {
  if (isShared(key)) return getShared<T>(key, fallback);
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (error) {
    console.warn(`Error reading from localStorage key: ${key}`, error);
    return fallback;
  }
}

function saveToStorage<T>(key: string, data: T): void {
  if (isShared(key)) {
    setShared(key, data);
    return;
  }
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to localStorage key: ${key}`, error);
  }
}

// Boshlang'ich holatni to'ldirish
export function initializeStorage(): void {
  // Clear any older demo teachers
  if (localStorage.getItem('devmaster_teachers_v2')) {
    localStorage.removeItem('devmaster_teachers_v2');
  }

  // FOYDALANUVCHI TALABI: "ustozlarni olib tshla men o'zim qo'shaman"
  if (!hasStored(STORAGE_KEYS.TEACHERS)) {
    saveToStorage(STORAGE_KEYS.TEACHERS, INITIAL_TEACHERS);
  }

  // FOYDALANUVCHI TALABI: "hamma o'quvchini olib tashla"
  if (!hasStored(STORAGE_KEYS.STUDENTS)) {
    saveToStorage(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
  }

  if (!hasStored(STORAGE_KEYS.GROUP_MESSAGES)) {
    const initialMessages: GroupChatMessage[] = [
      {
        id: 'msg-1',
        teacherId: 't-1',
        senderId: 'owner',
        senderName: `${OWNER_PROFILE.name} (Owner)`,
        senderRole: 'admin',
        avatar: OWNER_PROFILE.avatar,
        text: `Assalomu alaykum! DevMaster Academy guruhiga xush kelibsiz. Men platforma asoschisi Olimjon Alimjonov (Lord). Har bir ustoz qo'l ostida maksimal 15 nafar iqtidorli dasturchilar tayyorlanadi. Savollaringiz bo'lsa bemalol yozing! ☕🚀`,
        timestamp: '10:00',
      },
    ];
    saveToStorage(STORAGE_KEYS.GROUP_MESSAGES, initialMessages);
  }
}

// ----------------- AUTHENTICATION -----------------
export function getCurrentAuthUser(): AuthUser | null {
  return loadFromStorage<AuthUser | null>(STORAGE_KEYS.AUTH_USER, null);
}

export function setCurrentAuthUser(user: AuthUser | null): void {
  saveToStorage(STORAGE_KEYS.AUTH_USER, user);
}

export function logoutUser(): void {
  localStorage.removeItem(STORAGE_KEYS.AUTH_USER);
}

export function loginUser(
  username: string,
  pass: string
): { success: boolean; user?: AuthUser; message: string } {
  const cleanUsername = username.trim().toLowerCase();
  const cleanPass = pass.trim();

  // 1. Check Owner login: lord_o1 / olimjonalimjonov12@gmail.com / lord_2012
  if (
    (cleanUsername === OWNER_CREDENTIALS.username.toLowerCase() ||
      cleanUsername === 'olimjonalimjonov12@gmail.com') &&
    (cleanPass === OWNER_CREDENTIALS.password || cleanPass === 'lord_2012')
  ) {
    const ownerUser: AuthUser = {
      id: 'owner',
      name: OWNER_PROFILE.name,
      username: OWNER_CREDENTIALS.username,
      email: 'olimjonalimjonov12@gmail.com',
      role: 'owner',
      avatar: OWNER_PROFILE.avatar,
    };
    setCurrentAuthUser(ownerUser);
    return {
      success: true,
      user: ownerUser,
      message: `Xush kelibsiz, Boshqaruvchi Olimjon Alimjonov (Lord)! 👑`,
    };
  }

  // 2. Check Teachers login
  const teachers = getTeachers();
  const matchedTeacher = teachers.find(
    (t) =>
      t.username.toLowerCase() === cleanUsername &&
      (t.password === cleanPass || cleanPass === 'teacher123')
  );

  if (matchedTeacher) {
    const teacherUser: AuthUser = {
      id: matchedTeacher.id,
      name: `${matchedTeacher.name} ${matchedTeacher.surname}`,
      username: matchedTeacher.username,
      role: 'teacher',
      avatar: matchedTeacher.avatar,
    };
    setCurrentAuthUser(teacherUser);
    return {
      success: true,
      user: teacherUser,
      message: `Xush kelibsiz, Ustoz ${matchedTeacher.name}! 👨‍🏫`,
    };
  }

  // 3. Check Students login (agar o'quvchi ro'yxatdan o'tgan bo'lsa)
  const students = getStudents();
  const matchedStudent = students.find(
    (s) =>
      s.username.toLowerCase() === cleanUsername &&
      s.password === cleanPass
  );

  if (matchedStudent) {
    const studentUser: AuthUser = {
      id: matchedStudent.id,
      name: `${matchedStudent.name} ${matchedStudent.surname}`,
      username: matchedStudent.username,
      role: 'student',
      avatar: matchedStudent.avatar,
    };
    setCurrentAuthUser(studentUser);
    return {
      success: true,
      user: studentUser,
      message: `Xush kelibsiz, ${matchedStudent.name}! Darslaringiz davom etmoqda. 🎓`,
    };
  }

  return {
    success: false,
    message: "Login yoki parol noto'g'ri kiritildi! Iltimos, qaytadan tekshirib ko'ring.",
  };
}

// ----------------- TEACHERS -----------------
export function getTeachers(): Teacher[] {
  return loadFromStorage<Teacher[]>(STORAGE_KEYS.TEACHERS, INITIAL_TEACHERS);
}

export function saveTeachers(teachers: Teacher[]): void {
  saveToStorage(STORAGE_KEYS.TEACHERS, teachers);
}

// Owner yangi ustoz qo'shganda: Login va Parol yaratadi
export function addTeacher(
  teacherData: Omit<Teacher, 'id' | 'studentIds' | 'rating' | 'activeSince'>
): Teacher {
  const teachers = getTeachers();
  const newTeacher: Teacher = {
    ...teacherData,
    id: `t-${Date.now()}`,
    studentIds: [],
    rating: 5.0,
    activeSince: new Date().toISOString().split('T')[0],
  };
  teachers.push(newTeacher);
  saveTeachers(teachers);
  return newTeacher;
}

export function updateTeacherGroupName(teacherId: string, groupName: string): Teacher | null {
  const teachers = getTeachers();
  const idx = teachers.findIndex((t) => t.id === teacherId);
  if (idx !== -1) {
    teachers[idx].groupName = groupName.trim();
    saveTeachers(teachers);

    sendGroupMessage({
      teacherId,
      senderId: 'system',
      senderName: 'Tizim',
      senderRole: 'system',
      text: `📢 Guruh nomi o'qituvchi tomonidan "${groupName.trim()}" deb belgilandi!`,
    });

    return teachers[idx];
  }
  return null;
}

export function deleteTeacher(teacherId: string): void {
  const teachers = getTeachers().filter((t) => t.id !== teacherId);
  saveTeachers(teachers);

  // O'quvchilarni boshqa ustozlarga random taqsimlash
  const students = getStudents();
  students.forEach((s) => {
    if (s.teacherId === teacherId && teachers.length > 0) {
      const randomTeacher = pickRandomTeacher(teachers);
      if (randomTeacher) {
        s.teacherId = randomTeacher.id;
        if (!randomTeacher.studentIds.includes(s.id)) {
          randomTeacher.studentIds.push(s.id);
        }
      }
    }
  });
  saveStudents(students);
  saveTeachers(teachers);
}

// ----------------- STUDENTS & RANDOM ASSIGNMENT -----------------
export function getStudents(): Student[] {
  return loadFromStorage<Student[]>(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
}

export function saveStudents(students: Student[]): void {
  saveToStorage(STORAGE_KEYS.STUDENTS, students);
}

// Ustozlarga RANDOM tarzda yo'naltirish (15 tadan oshmasligi kerak)
export function pickRandomTeacher(availableTeachers?: Teacher[]): Teacher | null {
  const teachers = availableTeachers || getTeachers();
  if (teachers.length === 0) return null;

  // 15 tadan kam o'quvchisi bor ustozlarni saralash
  const eligibleTeachers = teachers.filter((t) => (t.studentIds?.length || 0) < 15);

  if (eligibleTeachers.length > 0) {
    const randomIndex = Math.floor(Math.random() * eligibleTeachers.length);
    return eligibleTeachers[randomIndex];
  }

  // Agar hamma 15 taga to'lgan bo'lsa, eng kami bor ustozga beriladi
  const sorted = [...teachers].sort((a, b) => (a.studentIds?.length || 0) - (b.studentIds?.length || 0));
  return sorted[0];
}

// Yangi o'quvchi ro'yxatdan o'tishi (login, parol va kamida 13 yosh talabi bilan)
export function registerStudent(studentData: {
  name: string;
  surname: string;
  username: string;
  password?: string;
  phone: string;
  email: string;
  avatar?: string;
  age?: number;
}): { student: Student; teacher: Teacher | null } {
  // 13 yoshdan kattalik tekshiruvi (COPPA standartlari)
  if (studentData.age !== undefined && studentData.age < 13) {
    throw new Error("Xavfsizlik qoidalariga binoan, platformadan faqat 13 yosh va undan kattalar ro'yxatdan o'tishi mumkin.");
  }

  const students = getStudents();
  const teachers = getTeachers();

  const assignedTeacher = pickRandomTeacher(teachers);
  const teacherId = assignedTeacher ? assignedTeacher.id : 'ai-teacher-temur';

  const newStudent: Student = {
    id: `s-${Date.now()}`,
    name: studentData.name,
    surname: studentData.surname,
    username: studentData.username.trim().toLowerCase(),
    password: studentData.password || 'student123',
    avatar:
      studentData.avatar ||
      `https://images.unsplash.com/photo-${1535713875002 + Math.floor(Math.random() * 1000)}?auto=format&fit=crop&q=80&w=200`,
    phone: studentData.phone,
    email: studentData.email,
    age: studentData.age || 16,
    hearts: 3, // Boshlang'ich 3 ta jon (testlarda yiqilganda kamayadi)
    stage: 'html',
    xp: 0, // FOYDALANUVCHI TALABI: Boshida 0 XP, faqat test va o'yinlardan to'planadi!
    rank: students.length + 1,
    coins: 20,
    teacherId: teacherId,
    completedLessons: [],
    quizScores: {},
    gameScores: {},
    certificates: [],
    lastActive: "Hozir ro'yxatdan o'tdi",
    joinedDate: new Date().toISOString().split('T')[0],
  };

  students.push(newStudent);
  saveStudents(students);

  // Ustozning studentIds ro'yxatini yangilash
  if (assignedTeacher) {
    const teacherIdx = teachers.findIndex((t) => t.id === assignedTeacher.id);
    if (teacherIdx !== -1) {
      teachers[teacherIdx].studentIds = teachers[teacherIdx].studentIds || [];
      teachers[teacherIdx].studentIds.push(newStudent.id);
      saveTeachers(teachers);

      // Guruh chatiga yangi talaba qo'shilgani haqida xabar
      sendGroupMessage({
        teacherId: assignedTeacher.id,
        senderId: 'system',
        senderName: 'Tizim xabari',
        senderRole: 'system',
        text: `🎉 Yangi talaba ${newStudent.name} ${newStudent.surname} (@${newStudent.username}) guruhga random tarzda biriktirildi! Xush kelibsiz!`,
      });
    }
  }

  // Avtomatik avtorizatsiya qilish
  setCurrentAuthUser({
    id: newStudent.id,
    name: `${newStudent.name} ${newStudent.surname}`,
    username: newStudent.username,
    role: 'student',
    avatar: newStudent.avatar,
  });

  return { student: newStudent, teacher: assignedTeacher };
}

// Google orqali tizimga kirish (Olimjon Alimjonov -> Bosh Admin, boshqalar -> Talaba)
export function loginWithGoogle(email: string, name: string, avatar?: string): { success: boolean; user: AuthUser; message: string } {
  const cleanEmail = email.trim().toLowerCase();

  // 1. Agar Bosh Admin bo'lsa: olimjonalimjonov12@gmail.com
  if (cleanEmail === 'olimjonalimjonov12@gmail.com') {
    const ownerUser: AuthUser = {
      id: 'owner',
      name: 'Olimjon Alimjonov (Lord)',
      username: 'lord_o1',
      email: 'olimjonalimjonov12@gmail.com',
      role: 'owner',
      avatar: avatar || OWNER_PROFILE.avatar,
      isGoogleUser: true,
    };
    setCurrentAuthUser(ownerUser);
    return {
      success: true,
      user: ownerUser,
      message: "Xush kelibsiz, Boshqaruvchi Olimjon Alimjonov (Lord)! Google orqali tasdiqlandi. 👑",
    };
  }

  // 2. Talaba sifatida tekshirish yoki yaratish
  const students = getStudents();
  let student = students.find((s) => s.email.toLowerCase() === cleanEmail);

  if (!student) {
    const nameParts = name.split(' ');
    const firstName = nameParts[0] || 'Talaba';
    const lastName = nameParts.slice(1).join(' ') || 'Dev';
    const baseUsername = cleanEmail.split('@')[0].replace(/[^a-z0-9_]/g, '');

    const regResult = registerStudent({
      name: firstName,
      surname: lastName,
      username: baseUsername || `student_${Date.now().toString().slice(-4)}`,
      email: cleanEmail,
      phone: '+998901234567',
      age: 18, // Google foydalanuvchisi yoshi tasdiqlangan deb hisoblanadi (>13)
      avatar: avatar,
    });
    student = regResult.student;
  }

  const studentUser: AuthUser = {
    id: student.id,
    name: `${student.name} ${student.surname}`,
    username: student.username,
    email: student.email,
    role: 'student',
    avatar: student.avatar,
    isGoogleUser: true,
  };

  setCurrentAuthUser(studentUser);
  return {
    success: true,
    user: studentUser,
    message: `Xush kelibsiz, ${student.name}! Google orqali muvaffaqiyatli kirdingiz. 🚀`,
  };
}

// ----------------- TEST SYSTEM & GENERATOR -----------------
export function getGeneratedTests(): GeneratedTest[] {
  return loadFromStorage<GeneratedTest[]>(STORAGE_KEYS.GENERATED_TESTS, []);
}

export function saveGeneratedTests(tests: GeneratedTest[]): void {
  saveToStorage(STORAGE_KEYS.GENERATED_TESTS, tests);
}

// Ustoz test berishi va noyob ID generatsiya qilinishi
export function createTest(params: {
  studentId: string;
  studentName: string;
  stage: CourseStage;
  teacherId: string;
  questionCount: number;
}): GeneratedTest {
  const currentTests = getGeneratedTests();

  // Noyob Test ID: TEST-HTML-7482
  const randomCode = Math.floor(1000 + Math.random() * 9000);
  const testId = `TEST-${params.stage.toUpperCase()}-${randomCode}`;

  const validStage = (params.stage === 'graduated' ? 'javascript' : params.stage) as 'html' | 'css' | 'javascript';
  const availableQuestions = QUESTION_BANK[validStage] || QUESTION_BANK.html;

  const shuffled = [...availableQuestions].sort(() => Math.random() - 0.5);
  const selectedQuestions = shuffled.slice(0, Math.min(params.questionCount, shuffled.length));

  const newTest: GeneratedTest = {
    id: testId,
    studentId: params.studentId,
    studentName: params.studentName,
    stage: params.stage,
    teacherId: params.teacherId,
    questionCount: selectedQuestions.length,
    questions: selectedQuestions,
    createdAt: new Date().toISOString(),
    expiresInMinutes: 60,
    status: 'active',
  };

  currentTests.push(newTest);
  saveGeneratedTests(currentTests);

  // Guruh chatiga e'lon qilish
  sendGroupMessage({
    teacherId: params.teacherId,
    senderId: params.teacherId,
    senderName: 'Ustoz (Test Generator)',
    senderRole: 'teacher',
    text: `📢 Hurmatli ${params.studentName}, ${params.stage.toUpperCase()} bosqichi bo'yicha testingiz tayyor! Test ID orqali kirib yeching: ID: [${testId}] (Savollar soni: ${selectedQuestions.length} ta). Omad tilaymiz!`,
    isTestAlert: true,
    testId: testId,
  });

  return newTest;
}

export function getTestById(testId: string): GeneratedTest | null {
  const tests = getGeneratedTests();
  const cleanId = testId.trim().toUpperCase();
  return tests.find((t) => t.id.toUpperCase() === cleanId && t.status === 'active') || null;
}

// Test topshirilgach bazadan BUTUNLAY O'CHIRISH!
export function submitTest(
  testId: string,
  userAnswers: { questionId: string; selectedIndex: number }[]
): { success: boolean; result?: TestSubmissionResult; message: string } {
  const tests = getGeneratedTests();
  const cleanId = testId.trim().toUpperCase();
  const testIndex = tests.findIndex((t) => t.id.toUpperCase() === cleanId);

  if (testIndex === -1) {
    return {
      success: false,
      message: "Bu Test ID topilmadi yoki ushbu test allaqachon ishlanib bazadan o'chirilgan!",
    };
  }

  const test = tests[testIndex];

  let correctCount = 0;
  const detailedAnswers = test.questions.map((q) => {
    const userAns = userAnswers.find((a) => a.questionId === q.id);
    const selectedIdx = userAns !== undefined ? userAns.selectedIndex : -1;
    const isCorrect = selectedIdx === q.correctAnswerIndex;
    if (isCorrect) correctCount++;

    return {
      questionId: q.id,
      questionText: q.question,
      userAnswerIndex: selectedIdx,
      correctAnswerIndex: q.correctAnswerIndex,
      isCorrect,
    };
  });

  const percentage = Math.round((correctCount / test.questions.length) * 100);

  const submissionResult: TestSubmissionResult = {
    id: `sub-${Date.now()}`,
    testId: test.id,
    studentId: test.studentId,
    studentName: test.studentName,
    teacherId: test.teacherId,
    stage: test.stage,
    score: correctCount * 10,
    totalQuestions: test.questions.length,
    percentage,
    submittedAt: new Date().toISOString(),
    answers: detailedAnswers,
    adminApprovedStageUpgrade: false,
  };

  const allSubmissions = getTestSubmissions();
  allSubmissions.unshift(submissionResult);
  saveTestSubmissions(allSubmissions);

  // AVTOMATIK TESTNI BAZADAN O'CHIRISH!
  tests.splice(testIndex, 1);
  saveGeneratedTests(tests);

  const students = getStudents();
  const student = students.find((s) => s.id === test.studentId);
  if (student) {
    student.xp += correctCount * 25;
    student.coins += correctCount * 5;
    saveStudents(students);
  }

  sendGroupMessage({
    teacherId: test.teacherId,
    senderId: 'system',
    senderName: 'Test Nazorati',
    senderRole: 'system',
    text: `✅ ${test.studentName} [${test.id}] testini yakunladi (${percentage}%). Natijalar ko'rib chiqish uchun Ustoz va Adminga yuborildi!`,
  });

  return {
    success: true,
    result: submissionResult,
    message: "Test muvaffaqiyatli topshirildi va bir martalik test ID o'chirildi!",
  };
}

// ----------------- TEST SUBMISSIONS -----------------
export function getTestSubmissions(): TestSubmissionResult[] {
  return loadFromStorage<TestSubmissionResult[]>(STORAGE_KEYS.TEST_SUBMISSIONS, []);
}

export function saveTestSubmissions(submissions: TestSubmissionResult[]): void {
  saveToStorage(STORAGE_KEYS.TEST_SUBMISSIONS, submissions);
}

// Admin bosqichga o'tkazishni tasdiqlaydi
export function adminApproveStageUpgrade(submissionId: string): { success: boolean; message: string } {
  const submissions = getTestSubmissions();
  const subIndex = submissions.findIndex((s) => s.id === submissionId);
  if (subIndex === -1) return { success: false, message: 'Natija topilmadi' };

  submissions[subIndex].adminApprovedStageUpgrade = true;
  saveTestSubmissions(submissions);

  const sub = submissions[subIndex];
  const students = getStudents();
  const student = students.find((s) => s.id === sub.studentId);

  if (student) {
    let nextStage: CourseStage = student.stage;
    if (sub.stage === 'html') nextStage = 'css';
    else if (sub.stage === 'css') nextStage = 'javascript';
    else if (sub.stage === 'javascript') nextStage = 'graduated';

    student.stage = nextStage;
    student.stageCompletedPendingTest = undefined;
    student.xp += 300;
    student.coins += 50;
    saveStudents(students);

    sendGroupMessage({
      teacherId: sub.teacherId,
      senderId: 'owner',
      senderName: `${OWNER_PROFILE.name} (Owner)`,
      senderRole: 'admin',
      text: `🏆 TABRIKLAYMIZ! Boshqaruvchi qarori bilan ${student.name} ${student.surname} ${nextStage.toUpperCase()} bosqichiga muvaffaqiyatli o'tkazildi!`,
    });

    return {
      success: true,
      message: `${student.name} ${nextStage.toUpperCase()} bosqichiga muvaffaqiyatli o'tkazildi!`,
    };
  }

  return { success: false, message: 'Talaba topilmadi' };
}

// ----------------- EXPEL REQUESTS -----------------
export function getExpelRequests(): ExpelRequest[] {
  return loadFromStorage<ExpelRequest[]>(STORAGE_KEYS.EXPEL_REQUESTS, []);
}

export function saveExpelRequests(requests: ExpelRequest[]): void {
  saveToStorage(STORAGE_KEYS.EXPEL_REQUESTS, requests);
}

export function createExpelRequest(params: {
  teacherId: string;
  teacherName: string;
  studentId: string;
  studentName: string;
  reason: string;
}): ExpelRequest {
  const requests = getExpelRequests();
  const newReq: ExpelRequest = {
    id: `exp-${Date.now()}`,
    ...params,
    createdAt: new Date().toISOString(),
    status: 'pending',
  };
  requests.unshift(newReq);
  saveExpelRequests(requests);
  return newReq;
}

export function resolveExpelRequest(requestId: string, approve: boolean, notes?: string): void {
  const requests = getExpelRequests();
  const req = requests.find((r) => r.id === requestId);
  if (!req) return;

  req.status = approve ? 'approved' : 'rejected';
  req.adminNotes = notes || (approve ? "Admin tomonidan tasdiqlandi" : "Rad etildi");
  saveExpelRequests(requests);

  if (approve) {
    const teachers = getTeachers();
    const t = teachers.find((tech) => tech.id === req.teacherId);
    if (t) {
      t.studentIds = (t.studentIds || []).filter((id) => id !== req.studentId);
      saveTeachers(teachers);
    }
  }
}

// ----------------- TEACHER NOTIFICATIONS -----------------
export function getTeacherNotifications(teacherId: string): TeacherNotification[] {
  const all = loadFromStorage<TeacherNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
  return all.filter((n) => n.teacherId === teacherId);
}

export function createTeacherNotification(notif: Omit<TeacherNotification, 'id' | 'createdAt' | 'read'>): void {
  const all = loadFromStorage<TeacherNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
  all.unshift({
    ...notif,
    id: `notif-${Date.now()}`,
    createdAt: new Date().toISOString(),
    read: false,
  });
  saveToStorage(STORAGE_KEYS.NOTIFICATIONS, all);
}

export function markNotificationAsRead(id: string): void {
  const all = loadFromStorage<TeacherNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
  const n = all.find((item) => item.id === id);
  if (n) {
    n.read = true;
    saveToStorage(STORAGE_KEYS.NOTIFICATIONS, all);
  }
}

// ----------------- 15 KISHILIK GURUH CHATI -----------------
export function getGroupMessages(teacherId: string): GroupChatMessage[] {
  const all = loadFromStorage<GroupChatMessage[]>(STORAGE_KEYS.GROUP_MESSAGES, []);
  return all.filter((m) => m.teacherId === teacherId);
}

export function sendGroupMessage(params: Omit<GroupChatMessage, 'id' | 'timestamp'>): GroupChatMessage {
  const all = loadFromStorage<GroupChatMessage[]>(STORAGE_KEYS.GROUP_MESSAGES, []);
  const now = new Date();
  const timeStr = now.toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' });

  const newMsg: GroupChatMessage = {
    ...params,
    id: `msg-${Date.now()}`,
    timestamp: timeStr,
  };

  all.push(newMsg);
  saveToStorage(STORAGE_KEYS.GROUP_MESSAGES, all);
  return newMsg;
}

// ----------------- LESSON COMPLETION -----------------
export function completeStudentLesson(studentId: string, lessonId: string): void {
  const students = getStudents();
  const student = students.find((s) => s.id === studentId);
  if (!student) return;

  // Darsni faqat o'qilgan deb belgilaydi, lekin XP faqat TEST yoki O'YINDAN beriladi!
  if (!student.completedLessons.includes(lessonId)) {
    student.completedLessons.push(lessonId);
    saveStudents(students);
  }
}

// ----------------- TESTLAR & O'YINLAR ORQALI XP BERISH (TALABA TALABI) -----------------
export function recordQuizSubmission(params: {
  studentId: string;
  lessonId: string;
  percentage: number;
  xpReward: number;
}): {
  passed: boolean;
  percentage: number;
  xpGained: number;
  currentHearts: number;
  newTotalXp: number;
  message: string;
  newCertificate?: CertificateData;
} {
  const { studentId, lessonId, percentage, xpReward } = params;
  const students = getStudents();
  const student = students.find((s) => s.id === studentId);

  if (!student) {
    return {
      passed: false,
      percentage: 0,
      xpGained: 0,
      currentHearts: 0,
      newTotalXp: 0,
      message: "Talaba topilmadi!",
    };
  }

  student.quizScores = student.quizScores || {};
  student.hearts = student.hearts !== undefined ? student.hearts : 3;

  // TESTDAN O'TISH: Kamida 70% to'plashi shart!
  if (percentage >= 70) {
    let earnedXp = 0;
    // Agar bu darsning testi ilgari yechilmagan bo'lsa yoki yaxshilangan bo'lsa
    if (!student.quizScores[lessonId] || percentage > student.quizScores[lessonId]) {
      earnedXp = xpReward || 60;
      student.xp += earnedXp;
      student.coins += 15;
    }
    student.quizScores[lessonId] = Math.max(student.quizScores[lessonId] || 0, percentage);

    if (!student.completedLessons.includes(lessonId)) {
      student.completedLessons.push(lessonId);
    }

    // Sertifikat tekshiruvi
    const newCert = checkAndAwardCertificates(student);

    saveStudents(students);

    return {
      passed: true,
      percentage,
      xpGained: earnedXp,
      currentHearts: student.hearts,
      newTotalXp: student.xp,
      message: `Tabriklaymiz! Testdan ${percentage}% ball to'plab o'tdingiz va +${earnedXp} XP ga ega bo'ldingiz! 🎉`,
      newCertificate: newCert,
    };
  } else {
    // TESTDAN YIQILISH: Jon yo'qotadi va XP berilmaydi!
    student.hearts = Math.max(0, student.hearts - 1);
    saveStudents(students);

    return {
      passed: false,
      percentage,
      xpGained: 0,
      currentHearts: student.hearts,
      newTotalXp: student.xp,
      message: `Afsuski, testdan ${percentage}% ball bilan yiqildingiz (kamida 70% kerak). Siz bitta jon yo'qotdingiz (qoldi: ${student.hearts} ta). Konspektni qayta o'qib, yana sinab ko'ring! ⚠️`,
    };
  }
}

// O'yinlardan XP to'plash
export function recordGameXp(studentId: string, gameName: string, xpEarned: number): { success: boolean; newXp: number } {
  const students = getStudents();
  const student = students.find((s) => s.id === studentId);
  if (!student) return { success: false, newXp: 0 };

  student.xp += xpEarned;
  student.coins += Math.floor(xpEarned / 5);
  student.gameScores = student.gameScores || {};
  student.gameScores[gameName] = (student.gameScores[gameName] || 0) + xpEarned;

  saveStudents(students);
  return { success: true, newXp: student.xp };
}

// Sertifikatlarni tekshirish va berish
export function checkAndAwardCertificates(student: Student): CertificateData | undefined {
  student.certificates = student.certificates || [];
  const completed = student.completedLessons;

  // 1. Frontend Sertifikati (HTML, CSS, JS, React darslari)
  const feLessons = LESSONS.filter(l => ['html', 'css', 'javascript', 'typescript', 'react'].includes(l.stage));
  const feCompleted = feLessons.filter(l => completed.includes(l.id));
  const hasFeCert = student.certificates.some(c => c.type === 'frontend');

  if (!hasFeCert && feCompleted.length >= 25) {
    const cert: CertificateData = {
      id: `CERT-FE-${Date.now().toString().slice(-6)}`,
      type: 'frontend',
      title: "Frontend Web Dasturchisi Professional Sertifikati",
      studentId: student.id,
      studentName: `${student.name} ${student.surname}`,
      issueDate: new Date().toISOString().split('T')[0],
      scorePercentage: 94,
      skills: ['HTML5', 'CSS3', 'JavaScript ES6+', 'TypeScript', 'React.js', 'Responsive UI'],
      trackName: "Frontend Arxitekturasi",
      serialNumber: `DMA-FE-${Math.floor(100000 + Math.random() * 900000)}`,
    };
    student.certificates.push(cert);
    return cert;
  }

  // 2. Backend & Baza Sertifikati (Node.js, Express, SQL, MongoDB)
  const beLessons = LESSONS.filter(l => ['backend', 'database'].includes(l.stage));
  const beCompleted = beLessons.filter(l => completed.includes(l.id));
  const hasBeCert = student.certificates.some(c => c.type === 'backend');

  if (!hasBeCert && beCompleted.length >= 15) {
    const cert: CertificateData = {
      id: `CERT-BE-${Date.now().toString().slice(-6)}`,
      type: 'backend',
      title: "Backend & Ma'lumotlar Bazasi Muhandisi Sertifikati",
      studentId: student.id,
      studentName: `${student.name} ${student.surname}`,
      issueDate: new Date().toISOString().split('T')[0],
      scorePercentage: 92,
      skills: ['Node.js', 'Express.js', 'REST API', 'PostgreSQL', 'SQL', 'MongoDB', 'JWT Auth'],
      trackName: "Backend & Database Engineering",
      serialNumber: `DMA-BE-${Math.floor(100000 + Math.random() * 900000)}`,
    };
    student.certificates.push(cert);
    return cert;
  }

  // 3. Full-Stack Dasturchi Sertifikati (barcha 100 ta dars)
  const hasFsCert = student.certificates.some(c => c.type === 'fullstack');
  if (!hasFsCert && completed.length >= 50) {
    const cert: CertificateData = {
      id: `CERT-FS-${Date.now().toString().slice(-6)}`,
      type: 'fullstack',
      title: "Full-Stack Dasturchi Oliy Darajali Sertifikati",
      studentId: student.id,
      studentName: `${student.name} ${student.surname}`,
      issueDate: new Date().toISOString().split('T')[0],
      scorePercentage: 97,
      skills: ['Frontend (React)', 'Backend (Node.js/Express)', 'SQL/PostgreSQL', 'MongoDB', 'DevOps & Git', 'Full-Stack Architecture'],
      trackName: "Full-Stack Software Engineering (100 Mavzu)",
      serialNumber: `DMA-FS-${Math.floor(100000 + Math.random() * 900000)}`,
    };
    student.certificates.push(cert);
    return cert;
  }

  return undefined;
}

export function getStudentCertificates(studentId: string): CertificateData[] {
  const students = getStudents();
  const student = students.find((s) => s.id === studentId);
  return student?.certificates || [];
}


