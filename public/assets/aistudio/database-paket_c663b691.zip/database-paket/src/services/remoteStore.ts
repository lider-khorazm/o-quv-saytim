// Markaziy ombor bilan sinxronlash.
// Ma'lumot xotirada (cache) turadi — shuning uchun storage.ts dagi funksiyalar sinxron qoladi.
// Har bir o'zgarish serverga yuboriladi, har 8 soniyada boshqalarning o'zgarishlari olinadi.

export type SyncStatus = 'connecting' | 'online' | 'offline';

const cache = new Map<string, unknown>(); // hozirgi qiymat
const base = new Map<string, unknown>(); // serverdan oxirgi marta olingan qiymat
const versions = new Map<string, number>();
const dirty = new Set<string>();
const pushing = new Set<string>();
const failed = new Set<string>();
let keys: string[] = [];
let status: SyncStatus = 'connecting';
let pollTimer: ReturnType<typeof setInterval> | null = null;

export const STORE_EVENT = 'devmaster-store-updated';
export const STATUS_EVENT = 'devmaster-sync-status';

export function getSyncStatus(): SyncStatus {
  return status;
}

function setStatus(next: SyncStatus) {
  if (status === next) return;
  status = next;
  window.dispatchEvent(new CustomEvent(STATUS_EVENT, { detail: next }));
}

function notifyChanged() {
  window.dispatchEvent(new Event(STORE_EVENT));
}

function readMirror(key: string): unknown | undefined {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : undefined;
  } catch {
    return undefined;
  }
}

function writeMirror(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* brauzer xotirasi to'lgan bo'lsa ham asosiy saqlash serverda */
  }
}

async function fetchJson(url: string, init?: RequestInit, timeoutMs = 8000): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

// ---- 3 tomonlama birlashtirish (id bo'yicha) ----
type Item = { id?: unknown };
const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

function merge(baseVal: unknown, mine: unknown, theirs: unknown): unknown {
  const arrs = [mine, theirs].every(Array.isArray);
  const baseArr = Array.isArray(baseVal) ? baseVal : [];
  if (!arrs) return mine;
  const all = [...(mine as Item[]), ...(theirs as Item[]), ...(baseArr as Item[])];
  if (!all.every((x) => x && typeof x === 'object' && typeof x.id === 'string')) return mine;

  const toMap = (a: Item[]) => new Map(a.map((x) => [x.id as string, x]));
  const b = toMap(baseArr as Item[]);
  const m = toMap(mine as Item[]);
  const result = toMap(theirs as Item[]);

  for (const [id, item] of m) {
    if (!result.has(id)) {
      // boshqasi o'chirgan bo'lsa-yu, men o'zgartirgan bo'lsam — saqlab qolamiz; yangi bo'lsa — qo'shamiz
      if (!b.has(id) || !same(item, b.get(id))) result.set(id, item);
    } else if (!same(item, b.get(id))) {
      result.set(id, item); // men o'zgartirgan yozuv
    }
  }
  for (const id of b.keys()) if (!m.has(id)) result.delete(id); // men o'chirgan yozuv
  return [...result.values()];
}

// ---- Yuborish ----
async function pushOnce(key: string): Promise<void> {
  for (let attempt = 0; attempt < 6; attempt++) {
    const mine = cache.get(key);
    const res = await fetchJson(`/api/store/${key}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ value: mine, baseVersion: versions.get(key) ?? 0 }),
    });
    if (res.ok) {
      const { version } = await res.json();
      versions.set(key, version);
      base.set(key, mine);
      return;
    }
    if (res.status === 409) {
      const { value: theirs, version } = await res.json();
      const merged = merge(base.get(key), cache.get(key), theirs);
      cache.set(key, merged);
      writeMirror(key, merged);
      base.set(key, theirs);
      versions.set(key, version);
      notifyChanged();
      continue;
    }
    throw new Error(`Server javobi: ${res.status}`);
  }
  throw new Error('Birlashtirishda takroriy ziddiyat');
}

function schedulePush(key: string) {
  dirty.add(key);
  if (pushing.has(key)) return;
  pushing.add(key);
  (async () => {
    try {
      while (dirty.has(key)) {
        dirty.delete(key);
        await pushOnce(key);
      }
      failed.delete(key);
      if (failed.size === 0) setStatus('online');
    } catch (err) {
      console.warn('Serverga saqlab bo\'lmadi, keyinroq qayta uriniladi:', key, err);
      failed.add(key);
      setStatus('offline');
    } finally {
      pushing.delete(key);
    }
  })();
}

// ---- Ommaviy API ----
export function isShared(key: string): boolean {
  return keys.includes(key);
}

export function hasShared(key: string): boolean {
  return cache.has(key);
}

export function getShared<T>(key: string, fallback: T): T {
  return cache.has(key) ? (cache.get(key) as T) : fallback;
}

export function setShared(key: string, value: unknown): void {
  cache.set(key, value);
  writeMirror(key, value);
  schedulePush(key);
}

async function pull(): Promise<boolean> {
  const res = await fetchJson('/api/store');
  if (!res.ok) throw new Error(`Server javobi: ${res.status}`);
  const data: { keys: Record<string, { value: unknown; version: number }> } = await res.json();
  let changed = false;
  for (const key of keys) {
    const row = data.keys[key];
    if (!row) continue;
    if (dirty.has(key) || pushing.has(key) || failed.has(key)) continue; // yuborilmagan o'zgarishlarni ustidan yozmaymiz
    if (versions.get(key) === row.version) continue;
    cache.set(key, row.value);
    base.set(key, row.value);
    versions.set(key, row.version);
    writeMirror(key, row.value);
    changed = true;
  }
  return changed;
}

export async function initRemote(sharedKeys: string[]): Promise<void> {
  keys = sharedKeys;
  try {
    const res = await fetchJson('/api/store');
    if (!res.ok) throw new Error(`Server javobi: ${res.status}`);
    const data: { keys: Record<string, { value: unknown; version: number }> } = await res.json();
    for (const key of keys) {
      const row = data.keys[key];
      if (row) {
        cache.set(key, row.value);
        base.set(key, row.value);
        versions.set(key, row.version);
        writeMirror(key, row.value);
      } else {
        // Serverda hali yo'q: shu brauzerdagi mavjud ma'lumotni (agar bo'lsa) markazga ko'chiramiz
        const local = readMirror(key);
        if (local !== undefined) {
          cache.set(key, local);
          versions.set(key, 0);
          base.set(key, []);
          schedulePush(key);
        }
      }
    }
    setStatus('online');
  } catch (err) {
    console.warn('Serverga ulanib bo\'lmadi — vaqtincha shu brauzer xotirasi ishlatiladi:', err);
    for (const key of keys) {
      const local = readMirror(key);
      if (local !== undefined) cache.set(key, local);
    }
    setStatus('offline');
  }
}

export function startPolling(intervalMs = 8000): void {
  if (pollTimer) return;
  pollTimer = setInterval(async () => {
    try {
      // Yuborilmay qolganlarini qayta urinib ko'ramiz
      for (const key of [...failed]) {
        failed.delete(key);
        if (!versions.has(key)) versions.set(key, 0);
        schedulePush(key);
      }
      if (await pull()) notifyChanged();
      if (failed.size === 0 && pushing.size === 0) setStatus('online');
    } catch {
      setStatus('offline');
    }
  }, intervalMs);
}
