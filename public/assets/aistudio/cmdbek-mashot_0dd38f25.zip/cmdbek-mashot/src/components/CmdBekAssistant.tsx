import { useEffect, useState } from 'react';
import { CmdBekMascot, type CmdBekMood } from './CmdBekMascot';
import { AiMentorModal } from './AiMentorModal';

/** Pastki o'ng burchakdagi suzuvchi CMDbek: bosilsa AI mentor chati ochiladi. */
export function CmdBekAssistant() {
  const [open, setOpen] = useState(false);
  const [bubble, setBubble] = useState(false);
  const [hover, setHover] = useState(false);

  useEffect(() => {
    const show = setTimeout(() => setBubble(true), 2500);
    const hide = setTimeout(() => setBubble(false), 10000);
    return () => {
      clearTimeout(show);
      clearTimeout(hide);
    };
  }, []);

  const mood: CmdBekMood = open ? 'happy' : hover ? 'explaining' : bubble ? 'hello' : 'idle';

  return (
    <>
      <div
        style={{
          position: 'fixed',
          right: 14,
          bottom: 'calc(14px + env(safe-area-inset-bottom, 0px))',
          zIndex: 60,
          display: 'flex',
          alignItems: 'flex-end',
          gap: 8,
        }}
      >
        {bubble && !open && (
          <div
            role="status"
            onClick={() => setOpen(true)}
            style={{
              marginBottom: 46,
              maxWidth: 200,
              padding: '10px 14px',
              borderRadius: '14px 14px 4px 14px',
              background: '#0e0c18',
              border: '1.5px solid #3ee6c4',
              color: '#b6f03c',
              fontFamily: 'JetBrains Mono, monospace',
              fontWeight: 700,
              fontSize: 13,
              boxShadow: '0 12px 30px -10px rgba(0,0,0,.7)',
              cursor: 'pointer',
              animation: 'dm-pop .35s both',
            }}
          >
            {'> Nimani tushuntirib beray?_'}
          </div>
        )}
        <button
          type="button"
          aria-label="AI ustoz CMDbek bilan suhbat"
          onClick={() => {
            setOpen(true);
            setBubble(false);
          }}
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
          style={{
            background: 'none',
            border: 0,
            padding: 0,
            minHeight: 0,
            borderRadius: 0,
            boxShadow: 'none',
            cursor: 'pointer',
            width: 'clamp(76px, 20vw, 112px)',
          }}
        >
          <CmdBekMascot mood={mood} size="100%" />
        </button>
      </div>
      <AiMentorModal isOpen={open} onClose={() => setOpen(false)} />
    </>
  );
}
